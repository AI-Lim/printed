import { useState, useRef } from 'react';
import { Upload, Type, Image, RotateCcw, Download, ShoppingCart } from 'lucide-react';
import { useCart } from '../context/AppContext';
import { MOCK_PRODUCTS, ASSETS } from '../utils/constants';

const PRODUCTS = [
  { id: 1, name: 'T-Shirt', image: ASSETS.tshirt1, color: '#E5A6A8' },
  { id: 2, name: 'Sweat', image: ASSETS.sweater, color: '#02AB84' },
  { id: 3, name: 'Mug', image: ASSETS.mug, color: '#E6B95E' },
  { id: 4, name: 'Sneakers', image: ASSETS.sneaker, color: '#017BFE' },
];

const FONTS = ['Arial', 'Georgia', 'Impact', 'Courier New', 'Comic Sans MS'];
const COLORS = ['#000000', '#FFFFFF', '#017BFE', '#E6B95E', '#E5A6A8', '#02AB84', '#EF4444', '#8B5CF6'];
const MODELS = ['🌿 Nature', '🐾 Animaux', '🎌 Otaku', '💪 Motivation', '🎮 Gaming', '🎨 Abstrait'];

export default function Personnalisation() {
  const { addItem } = useCart();
  const [selectedProduct, setSelectedProduct] = useState(PRODUCTS[0]);
  const [tool, setTool] = useState('text');
  const [text, setText] = useState('Mon texte');
  const [textColor, setTextColor] = useState('#000000');
  const [textFont, setTextFont] = useState('Arial');
  const [textSize, setTextSize] = useState(24);
  const [uploadedImg, setUploadedImg] = useState(null);
  const [selectedModel, setSelectedModel] = useState(null);
  const [added, setAdded] = useState(false);
  const fileRef = useRef();

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setUploadedImg(ev.target.result);
    reader.readAsDataURL(file);
  };

  const handleAddToCart = () => {
    addItem({ ...MOCK_PRODUCTS[0], name: `${selectedProduct.name} Personnalisé`, id: Date.now() });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div>
      <div style={{ background: 'linear-gradient(135deg, #017BFE 0%, #00C2FF 100%)', padding: '48px 24px', textAlign: 'center', color: 'white', marginBottom: 40 }}>
        <h1 style={{ fontSize: 40, fontWeight: 800, marginBottom: 12, fontFamily: "'Mochiy Pop One', sans-serif" }}>Personnalisez votre article</h1>
        <p style={{ fontSize: 16, opacity: 0.9 }}>Créez un design unique en quelques clics</p>
      </div>

      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px 60px', display: 'grid', gridTemplateColumns: '280px 1fr 280px', gap: 24 }}>

        {/* Left: Tools */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Product picker */}
          <div style={{ background: 'white', borderRadius: 20, padding: 20, boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 6 }}>🛍️ Choisir le produit</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {PRODUCTS.map(p => (
                <div key={p.id} onClick={() => setSelectedProduct(p)} style={{ border: `2px solid ${selectedProduct.id === p.id ? '#017BFE' : '#e5e7eb'}`, borderRadius: 12, padding: 10, cursor: 'pointer', textAlign: 'center', background: selectedProduct.id === p.id ? '#E5F4FF' : 'white', transition: 'all 0.2s' }}>
                  <div style={{ width: '100%', height: 60, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 4 }}>
                    <img src={p.image} alt={p.name} style={{ height: '100%', objectFit: 'contain' }} onError={e => e.target.style.display='none'} />
                  </div>
                  <p style={{ fontSize: 11, fontWeight: 600, color: selectedProduct.id === p.id ? '#017BFE' : '#232323' }}>{p.name}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Tool selector */}
          <div style={{ background: 'white', borderRadius: 20, padding: 20, boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>🎨 Outils</h3>
            <div style={{ display: 'flex', gap: 8 }}>
              {[
                { id: 'text', icon: Type, label: 'Texte' },
                { id: 'image', icon: Upload, label: 'Image' },
                { id: 'model', icon: Image, label: 'Modèle' },
              ].map(t => (
                <button key={t.id} onClick={() => setTool(t.id)} style={{ flex: 1, padding: '10px 4px', border: `2px solid ${tool === t.id ? '#017BFE' : '#e5e7eb'}`, borderRadius: 12, background: tool === t.id ? '#017BFE' : 'white', color: tool === t.id ? 'white' : '#555', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 600 }}>
                  <t.icon size={16} />{t.label}
                </button>
              ))}
            </div>

            {tool === 'text' && (
              <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 4 }}>Texte</label>
                  <input value={text} onChange={e => setText(e.target.value)} style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 10, padding: '8px 10px', fontSize: 14, outline: 'none', fontFamily: textFont }} />
                </div>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 4 }}>Police</label>
                  <select value={textFont} onChange={e => setTextFont(e.target.value)} style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 10, padding: '8px 10px', fontSize: 13, outline: 'none' }}>
                    {FONTS.map(f => <option key={f} value={f} style={{ fontFamily: f }}>{f}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 4 }}>Taille : {textSize}px</label>
                  <input type="range" min={12} max={72} value={textSize} onChange={e => setTextSize(Number(e.target.value))} style={{ width: '100%', accentColor: '#017BFE' }} />
                </div>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 6 }}>Couleur</label>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                    {COLORS.map(c => (
                      <div key={c} onClick={() => setTextColor(c)} style={{ width: 28, height: 28, borderRadius: '50%', background: c, cursor: 'pointer', border: textColor === c ? '3px solid #017BFE' : '2px solid #e5e7eb', transition: 'transform 0.1s', transform: textColor === c ? 'scale(1.2)' : 'scale(1)' }} />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {tool === 'image' && (
              <div style={{ marginTop: 16 }}>
                <input ref={fileRef} type="file" accept="image/*" onChange={handleFileUpload} style={{ display: 'none' }} />
                <button onClick={() => fileRef.current.click()} style={{ width: '100%', border: '2px dashed #017BFE', borderRadius: 12, padding: '20px', background: 'none', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, color: '#017BFE' }}>
                  <Upload size={24} />
                  <span style={{ fontSize: 13, fontWeight: 600 }}>Télécharger une image</span>
                  <span style={{ fontSize: 11, color: '#888' }}>PNG, JPG max 5MB</span>
                </button>
              </div>
            )}

            {tool === 'model' && (
              <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
                {MODELS.map(m => (
                  <button key={m} onClick={() => setSelectedModel(m)} style={{ width: '100%', padding: '10px 14px', border: `2px solid ${selectedModel === m ? '#017BFE' : '#e5e7eb'}`, borderRadius: 12, background: selectedModel === m ? '#E5F4FF' : 'white', cursor: 'pointer', fontSize: 13, fontWeight: 600, textAlign: 'left', color: selectedModel === m ? '#017BFE' : '#232323' }}>
                    {m}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Center: Preview */}
        <div style={{ background: 'white', borderRadius: 24, boxShadow: '0 4px 24px rgba(0,0,0,0.08)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          <div style={{ background: '#F4F4F4', padding: '12px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #eee' }}>
            <span style={{ fontSize: 14, fontWeight: 700 }}>Aperçu en temps réel</span>
            <div style={{ display: 'flex', gap: 8 }}>
              <button style={{ background: 'none', border: '1px solid #ddd', borderRadius: 20, padding: '4px 12px', fontSize: 12, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}><RotateCcw size={12} /> Réinitialiser</button>
            </div>
          </div>

          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40, minHeight: 500, position: 'relative', background: '#FAFAFA' }}>
            <div style={{ position: 'relative', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ width: 300, height: 300, background: selectedProduct.color + '33', borderRadius: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
                <img src={selectedProduct.image} alt={selectedProduct.name} style={{ maxWidth: '80%', maxHeight: '80%', objectFit: 'contain', position: 'relative', zIndex: 1 }} onError={e => e.target.style.display='none'} />
                {uploadedImg && (
                  <img src={uploadedImg} alt="custom" style={{ position: 'absolute', top: '30%', left: '30%', width: '40%', height: '40%', objectFit: 'contain', zIndex: 2, cursor: 'move' }} />
                )}
                {tool === 'text' && text && (
                  <div style={{ position: 'absolute', top: '35%', left: '50%', transform: 'translateX(-50%)', fontSize: textSize * 0.6, fontFamily: textFont, color: textColor, fontWeight: 700, zIndex: 2, whiteSpace: 'nowrap', cursor: 'move', textShadow: textColor === '#FFFFFF' ? '0 0 4px #000' : 'none' }}>
                    {text}
                  </div>
                )}
                {selectedModel && (
                  <div style={{ position: 'absolute', top: '30%', left: '50%', transform: 'translateX(-50%)', fontSize: 48, zIndex: 2 }}>
                    {selectedModel.split(' ')[0]}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div style={{ padding: '16px 24px', borderTop: '1px solid #eee', display: 'flex', gap: 12 }}>
            <button style={{ flex: 1, border: '2px solid #017BFE', borderRadius: 28, padding: '12px', background: 'none', color: '#017BFE', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, fontSize: 14 }}>
              <Download size={16} /> Télécharger l'aperçu
            </button>
            <button onClick={handleAddToCart} style={{ flex: 1, background: added ? '#02AB84' : '#017BFE', border: 'none', borderRadius: 28, padding: '12px', color: 'white', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, fontSize: 14, transition: 'background 0.3s' }}>
              <ShoppingCart size={16} />{added ? 'Ajouté ✓' : 'Ajouter au panier'}
            </button>
          </div>
        </div>

        {/* Right: Options */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ background: 'white', borderRadius: 20, padding: 20, boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>🎨 Couleur du produit</h3>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {['#FFFFFF', '#000000', '#017BFE', '#E5A6A8', '#02AB84', '#E6B95E', '#EF4444', '#F4F4F4'].map(c => (
                <div key={c} title={c} style={{ width: 36, height: 36, borderRadius: '50%', background: c, cursor: 'pointer', border: '2px solid #e5e7eb', transition: 'transform 0.1s' }}
                  onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.15)'}
                  onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'} />
              ))}
            </div>
          </div>

          <div style={{ background: 'white', borderRadius: 20, padding: 20, boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>📐 Taille</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
              {['XS','S','M','L','XL','XXL'].map(s => (
                <button key={s} style={{ border: '1px solid #e5e7eb', borderRadius: 10, padding: '8px', cursor: 'pointer', background: s === 'M' ? '#017BFE' : 'white', color: s === 'M' ? 'white' : '#232323', fontWeight: 700, fontSize: 13 }}>{s}</button>
              ))}
            </div>
          </div>

          <div style={{ background: '#CBF6FD', borderRadius: 20, padding: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 10 }}>💡 Conseils</h3>
            <ul style={{ fontSize: 12, color: '#444', lineHeight: 2, paddingLeft: 16 }}>
              <li>Utilisez des images PNG pour un meilleur rendu</li>
              <li>Résolution minimale recommandée : 300 DPI</li>
              <li>Le texte peut être redimensionné et déplacé</li>
              <li>Prévisualisez avant de commander</li>
            </ul>
          </div>

          <div style={{ background: 'white', borderRadius: 20, padding: 20, boxShadow: '0 4px 16px rgba(0,0,0,0.06)', textAlign: 'center' }}>
            <p style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>Prix estimé</p>
            <p style={{ fontSize: 28, fontWeight: 800, color: '#017BFE' }}>15 000 FCFA</p>
            <p style={{ fontSize: 11, color: '#aaa' }}>Livraison gratuite</p>
          </div>
        </div>
      </div>
    </div>
  );
}
