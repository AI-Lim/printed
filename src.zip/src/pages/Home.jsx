import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Star, ChevronRight, Check, ArrowRight } from 'lucide-react';
import { FIGMA_ASSETS, MOCK_PRODUCTS } from '../utils/constants';
import ProductCard from '../components/ui/ProductCard';

const REVIEWS = [
  { name: 'Ayo K.',   rating: 5,   text: "Qualité impressionnante ! Mon t-shirt Otaku est exactement comme sur la preview. Livraison rapide au Bénin !" },
  { name: 'Fatou M.', rating: 5,   text: "Super service ! J'ai commandé des mugs personnalisés pour notre entreprise. Le résultat est impeccable." },
  { name: 'Koffi D.', rating: 4.8, text: "L'outil de personnalisation est très simple à utiliser. Je recommande Printed à tous mes amis !" },
];

const FAQ_ITEMS = [
  { q: "Comment puis-je personnaliser un article ?",       a: "Choisissez un produit, téléchargez votre image ou choisissez parmi nos modèles, prévisualisez en temps réel, puis commandez !" },
  { q: "Quels sont les délais de livraison ?",             a: "3 à 7 jours ouvrés au Bénin. Pour Cotonou et environs : 24-48h possible." },
  { q: "Quels sont les moyens de paiement acceptés ?",     a: "Mobile Money (MTN, Moov, Celtiis) et carte bancaire (Visa/Mastercard)." },
  { q: "Quels types d'articles proposez-vous ?",           a: "Vêtements (T-shirts, sweats, pantalons), accessoires (mugs, casquettes, sacs) et objets personnalisés." },
  { q: "Comment puis-je contacter le service client ?",    a: "Par email à mailprinted@gmail.com, par téléphone +229 01 00 00 00 00, ou via notre formulaire de contact." },
];

const WHY_US = [
  { icon: '🚚', title: 'Livraison rapide',         desc: 'Recevez vos commandes dans les meilleurs délais, directement chez vous.',          bg: '#E5F4FF' },
  { icon: '🎨', title: 'Personnalisation ilimitée', desc: 'Ajoutez vos images, textes et designs sans aucune restriction.',                   bg: '#F0FFF8' },
  { icon: '⭐', title: 'Impression de qualité',     desc: "Techniques d'impression durables et matériaux de premier choix.",                  bg: '#FFF8E5' },
  { icon: '🎧', title: 'Support client réactif',    desc: 'Une équipe à votre écoute pour répondre à toutes vos questions.',                 bg: '#F5F0FF' },
];

export default function Home() {
  const [activeTab, setActiveTab] = useState('Tout');
  const [openFaq,   setOpenFaq]   = useState(null);
  const [email,     setEmail]     = useState('');
  const [subDone,   setSubDone]   = useState(false);

  const tabs = ['Tout', 'Plus vendu', 'Populaire'];
  const featured = MOCK_PRODUCTS.slice(0, 5);

  return (
    <div>
      {/* ── HERO ── */}
      <section style={{ maxWidth: 1280, margin: '0 auto', padding: '60px 24px 0', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'center', minHeight: 560 }}>
        <div className="fadeIn">
          <p style={{ fontSize: 13, fontWeight: 700, color: '#017BFE', textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12 }}>
            🎨 Impression à la demande — Bénin
          </p>
          <h1 style={{ fontSize: 48, fontWeight: 800, lineHeight: 1.2, marginBottom: 20, fontFamily: 'Poppins, sans-serif' }}>
            <span style={{ color: '#017BFE' }}>Personnalisez</span> votre style,{' '}
            <span style={{ color: '#232323' }}>Exprimez</span> votre créativité
          </h1>
          <p style={{ fontSize: 15, color: '#666', marginBottom: 36, lineHeight: 1.8, fontFamily: "'Mochiy Pop One', sans-serif" }}>
            Explorez nos collections de vêtements, mugs, accessoires et bien plus encore. Ajoutez votre touche personnelle à chaque produit !!!
          </p>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            <Link to="/personnalisation" style={{
              display: 'inline-flex', alignItems: 'center', gap: 8,
              background: '#017BFE', color: 'white',
              padding: '14px 32px', borderRadius: 28,
              fontWeight: 700, textDecoration: 'none', fontSize: 15,
              fontFamily: "'Mochiy Pop One', sans-serif",
              boxShadow: '0 4px 20px rgba(1,123,254,0.4)',
            }}>
              Créer mon design <ChevronRight size={18} />
            </Link>
            <Link to="/catalogue" style={{
              display: 'inline-flex', alignItems: 'center', gap: 8,
              border: '2px solid #017BFE', color: '#017BFE',
              padding: '14px 28px', borderRadius: 28,
              fontWeight: 700, textDecoration: 'none', fontSize: 15,
            }}>
              Voir le catalogue
            </Link>
          </div>
        </div>

        {/* Hero visual */}
        <div style={{ position: 'relative', height: 480, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ position: 'absolute', top: 20, left: 80, width: 190, height: 270, background: '#02AB84', borderRadius: 20, border: '5px solid white', overflow: 'hidden', boxShadow: '0 8px 24px rgba(0,0,0,0.15)' }}>
            <img src={FIGMA_ASSETS.zoro} alt="Zoro" style={{ width: '100%', height: '100%', objectFit: 'cover' }} onError={e => e.target.style.opacity='0'} />
          </div>
          <div style={{ position: 'absolute', top: 140, right: 20, width: 185, height: 180, background: '#E6B95E', borderRadius: 20, border: '5px solid white', overflow: 'hidden', boxShadow: '0 8px 24px rgba(0,0,0,0.15)' }}>
            <img src={FIGMA_ASSETS.product3} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} onError={e => e.target.style.opacity='0'} />
          </div>
          <div style={{ position: 'absolute', bottom: 20, left: 40, width: 270, height: 185, background: '#E5A6A8', borderRadius: 20, border: '5px solid white', overflow: 'hidden', boxShadow: '0 8px 24px rgba(0,0,0,0.15)' }}>
            <img src={FIGMA_ASSETS.sneaker} alt="Sneaker" style={{ width: '100%', height: '100%', objectFit: 'cover' }} onError={e => e.target.style.opacity='0'} />
          </div>
          <div style={{ position: 'absolute', top: 0, right: 50, width: 64, height: 64, background: '#CBF6FD', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>⭐</div>
          <div style={{ position: 'absolute', bottom: 80, right: 10, width: 28, height: 28, background: '#017BFE', borderRadius: '50%', opacity: 0.5 }} />
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section style={{ background: '#CBF6FD', padding: '64px 24px', marginTop: 48 }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[FIGMA_ASSETS.product1, FIGMA_ASSETS.product2, FIGMA_ASSETS.product3, FIGMA_ASSETS.product4].map((img, i) => (
              <div key={i} style={{ borderRadius: [20,0,0,20][i] + 'px ' + [0,20,20,0][i] + 'px ' + [0,20,20,0][i] + 'px ' + [20,0,0,20][i] + 'px', overflow: 'hidden', height: 185, background: '#ddd', border: '3px solid white', boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }}>
                <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} onError={e => e.target.style.opacity='0'} />
              </div>
            ))}
          </div>
          <div>
            <p style={{ fontSize: 12, fontWeight: 700, color: '#017BFE', textTransform: 'uppercase', letterSpacing: 2, marginBottom: 10 }}>À PROPOS DE NOUS</p>
            <h2 style={{ fontSize: 32, fontWeight: 800, marginBottom: 16, lineHeight: 1.3 }}>
              <span style={{ color: '#017BFE' }}>Printed</span> — L'impression à la demande au Bénin
            </h2>
            <p style={{ color: '#555', lineHeight: 1.8, marginBottom: 24, fontSize: 14 }}>
              Printed se positionne comme une solution innovante sur le marché béninois, offrant aux clients la possibilité de visualiser, personnaliser et commander des articles directement en ligne, qu'il s'agisse de vêtements, d'accessoires ou d'objets du quotidien.
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {['Livraison rapide', 'Qualité premium', 'Support 24/7', 'Satisfaction garantie'].map(item => (
                <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 22, height: 22, borderRadius: '50%', background: '#017BFE', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Check size={13} color="white" />
                  </div>
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── WHY US ── */}
      <section style={{ padding: '64px 24px', maxWidth: 1280, margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center', fontSize: 36, fontWeight: 800, marginBottom: 10 }}>Pourquoi nous?</h2>
        <p style={{ textAlign: 'center', color: '#888', marginBottom: 48, fontSize: 15 }}>Ce qui fait notre différence</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 24 }}>
          {WHY_US.map((item, i) => (
            <div key={i} style={{ borderRadius: 17, background: 'white', boxShadow: '4px 4px 20px rgba(0,0,0,0.07)', padding: '28px 24px', transition: 'transform 0.2s', cursor: 'default' }}
              onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-4px)'}
              onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}>
              <div style={{ width: 64, height: 64, background: item.bg, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, marginBottom: 18 }}>
                {item.icon}
              </div>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: '#017BFE', marginBottom: 8, fontFamily: "'Mochiy Pop One', sans-serif" }}>{item.title}</h3>
              <p style={{ fontSize: 12, color: '#666', lineHeight: 1.7 }}>{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── BRAND STRIP ── */}
      <div style={{ background: '#017BFE', padding: '16px 24px', overflow: 'hidden' }}>
        <div style={{ display: 'flex', gap: 48, justifyContent: 'center', flexWrap: 'wrap' }}>
          {Array(6).fill(null).map((_, i) => (
            <span key={i} style={{ color: 'white', fontWeight: 700, fontSize: 18, fontFamily: "'Mochiy Pop One', sans-serif", opacity: 0.9 }}>
              Print'ed ✦
            </span>
          ))}
        </div>
      </div>

      {/* ── PRODUCTS ── */}
      <section style={{ padding: '64px 24px', background: '#F4F4F4' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <h2 style={{ fontSize: 24, fontWeight: 800 }}>Nos produits</h2>
            <Link to="/catalogue" style={{ background: '#017BFE', color: 'white', padding: '9px 22px', borderRadius: 28, textDecoration: 'none', fontSize: 13, fontWeight: 700 }}>
              Voir plus +
            </Link>
          </div>
          <p style={{ fontSize: 16, marginBottom: 24, color: '#555' }}>
            Découvrez nos <span style={{ color: '#017BFE', fontWeight: 700 }}>meilleurs produits</span>
          </p>
          <div style={{ display: 'flex', gap: 10, marginBottom: 24 }}>
            {tabs.map(t => (
              <button key={t} onClick={() => setActiveTab(t)} style={{
                padding: '7px 18px', borderRadius: 28, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 700,
                background: activeTab === t ? '#017BFE' : 'transparent',
                color:      activeTab === t ? 'white' : '#666',
                transition: 'all 0.2s',
              }}>{t}</button>
            ))}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 20 }}>
            {featured.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      </section>

      {/* ── REVIEWS ── */}
      <section style={{ padding: '64px 24px', background: '#CBF6FD' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <h2 style={{ textAlign: 'center', fontSize: 32, fontWeight: 800, marginBottom: 10 }}>Ce qu'ils disent de nous</h2>
          <p style={{ textAlign: 'center', color: '#666', marginBottom: 48, fontSize: 14 }}>La confiance de nos clients, notre plus grande fierté</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20 }}>
            {REVIEWS.map((r, i) => (
              <div key={i} style={{ background: 'white', borderRadius: 17, padding: 24, boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
                  <div style={{ width: 44, height: 44, borderRadius: '50%', background: '#CBF6FD', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 18, color: '#017BFE' }}>{r.name[0]}</div>
                  <div>
                    <p style={{ fontWeight: 700, fontSize: 14, fontFamily: "'Mochiy Pop One', sans-serif" }}>{r.name}</p>
                    <div style={{ display: 'flex', gap: 2, marginTop: 2 }}>
                      {[1,2,3,4,5].map(s => <Star key={s} size={11} fill="#E6B95E" stroke="#E6B95E" />)}
                      <span style={{ fontSize: 11, color: '#aaa', marginLeft: 4 }}>{r.rating}</span>
                    </div>
                  </div>
                </div>
                <p style={{ fontSize: 13, color: '#555', lineHeight: 1.7 }}>{r.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section style={{ padding: '64px 24px' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }}>
          <div>
            <h2 style={{ fontSize: 32, fontWeight: 800, marginBottom: 32 }}>Questions fréquentes</h2>
            {FAQ_ITEMS.map((item, i) => (
              <div key={i} style={{ marginBottom: 10, background: 'white', borderRadius: 17, boxShadow: '0 2px 10px rgba(0,0,0,0.06)', overflow: 'hidden' }}>
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{
                  width: '100%', padding: '16px 20px',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  background: 'none', border: 'none', cursor: 'pointer',
                  fontSize: 14, fontWeight: 600, fontFamily: "'Mochiy Pop One', sans-serif",
                  textAlign: 'left',
                }}>
                  <span>{item.q}</span>
                  <span style={{ fontSize: 20, color: '#017BFE', transition: 'transform 0.2s', transform: openFaq === i ? 'rotate(45deg)' : 'none', flexShrink: 0, marginLeft: 12 }}>+</span>
                </button>
                {openFaq === i && (
                  <div style={{ padding: '0 20px 16px', fontSize: 13, color: '#666', lineHeight: 1.8 }}>
                    {item.a}
                  </div>
                )}
              </div>
            ))}
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 90, marginBottom: 20 }}>❓</div>
            <h2 style={{ fontSize: 32, fontWeight: 800, color: '#232323', marginBottom: 12 }}>Des questions ?</h2>
            <p style={{ color: '#666', marginBottom: 32, fontSize: 15, lineHeight: 1.7 }}>Consultez notre FAQ ou contactez directement notre équipe</p>
            <Link to="/contact" style={{ background: '#017BFE', color: 'white', padding: '14px 36px', borderRadius: 28, textDecoration: 'none', fontWeight: 700, fontSize: 15, display: 'inline-flex', alignItems: 'center', gap: 8 }}>
              Nous contacter <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* ── CTA + NEWSLETTER ── */}
      <section style={{ background: '#CBF6FD', padding: '64px 24px', textAlign: 'center' }}>
        <h2 style={{ fontSize: 32, color: '#017BFE', fontWeight: 800, marginBottom: 20 }}>Créez votre produit unique dès maintenant !</h2>
        <Link to="/personnalisation" style={{
          display: 'inline-block', background: '#017BFE', color: 'white',
          padding: '16px 52px', borderRadius: 28, textDecoration: 'none',
          fontWeight: 700, fontSize: 22, fontFamily: "'Mochiy Pop One', sans-serif",
          boxShadow: '0 4px 20px rgba(1,123,254,0.4)', marginBottom: 56,
        }}>
          commencer
        </Link>
        <div style={{ maxWidth: 640, margin: '0 auto' }}>
          <p style={{ fontSize: 17, color: '#444', marginBottom: 24, lineHeight: 1.7 }}>
            Recevez les dernières tendances, promotions et offres exclusives en vous abonnant à notre newsletter.
          </p>
          {subDone ? (
            <p style={{ fontSize: 16, fontWeight: 700, color: '#02AB84' }}>✅ Merci pour votre inscription !</p>
          ) : (
            <form onSubmit={e => { e.preventDefault(); setSubDone(true); }}
              style={{ display: 'flex', borderRadius: 17, overflow: 'hidden', boxShadow: '0 4px 20px rgba(0,0,0,0.08)', maxWidth: 520, margin: '0 auto' }}>
              <input
                type="email" required value={email} onChange={e => setEmail(e.target.value)}
                placeholder="Entrez votre mail"
                style={{ flex: 1, padding: '16px 20px', border: 'none', outline: 'none', fontSize: 14, fontFamily: 'Poppins, sans-serif' }}
              />
              <button type="submit" style={{
                background: '#017BFE', color: 'white', border: 'none',
                padding: '16px 28px', fontWeight: 700, cursor: 'pointer',
                fontSize: 14, fontFamily: "'Mochiy Pop One', sans-serif",
                whiteSpace: 'nowrap',
              }}>
                S'inscrire
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  );
}
