import { Link } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../context/AppContext';

export default function Cart() {
  const { items, removeItem, updateQty, total, clearCart } = useCart();
  const shipping = total >= 15000 ? 0 : 2000;
  const finalTotal = total + shipping;

  if (items.length === 0) {
    return (
      <div style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 40 }}>
        <div style={{ fontSize: 80, marginBottom: 20 }}>🛒</div>
        <h2 style={{ fontSize: 28, fontWeight: 800, marginBottom: 12 }}>Votre panier est vide</h2>
        <p style={{ color: '#666', marginBottom: 32 }}>Découvrez nos produits et ajoutez-les à votre panier</p>
        <Link to="/catalogue" style={{ background: '#017BFE', color: 'white', padding: '14px 32px', borderRadius: 28, textDecoration: 'none', fontWeight: 700, fontSize: 16 }}>
          Voir le catalogue
        </Link>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '40px 24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 }}>
        <h1 style={{ fontSize: 32, fontWeight: 800 }}>Mon Panier <span style={{ color: '#017BFE' }}>({items.length})</span></h1>
        <button onClick={clearCart} style={{ background: 'none', border: '1px solid #fecaca', color: '#ef4444', borderRadius: 20, padding: '8px 16px', cursor: 'pointer', fontSize: 13, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>
          <Trash2 size={14} /> Vider le panier
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 32 }}>
        {/* Items */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {items.map(item => (
            <div key={item.id} style={{ background: 'white', borderRadius: 16, padding: 20, boxShadow: '0 2px 12px rgba(0,0,0,0.06)', display: 'flex', gap: 20, alignItems: 'center' }}>
              <div style={{ width: 100, height: 100, borderRadius: 12, overflow: 'hidden', background: '#F9F9F9', flexShrink: 0 }}>
                <img src={item.image} alt={item.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} onError={e => e.target.style.display='none'} />
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontWeight: 700, fontSize: 16, marginBottom: 4, fontFamily: "'Mochiy Pop One', sans-serif" }}>{item.name}</p>
                {item.size && <p style={{ fontSize: 13, color: '#888', marginBottom: 4 }}>Taille : {item.size}</p>}
                <p style={{ fontSize: 16, fontWeight: 700, color: '#017BFE' }}>{item.price?.toLocaleString('fr-FR')} FCFA</p>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 12 }}>
                <button onClick={() => removeItem(item.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ef4444', display: 'flex' }}>
                  <Trash2 size={16} />
                </button>
                <div style={{ display: 'flex', alignItems: 'center', gap: 0, border: '1px solid #e5e7eb', borderRadius: 20, overflow: 'hidden' }}>
                  <button onClick={() => updateQty(item.id, item.qty - 1)} style={{ width: 32, height: 32, border: 'none', background: '#F4F4F4', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Minus size={12} />
                  </button>
                  <span style={{ width: 40, textAlign: 'center', fontSize: 15, fontWeight: 700 }}>{item.qty}</span>
                  <button onClick={() => updateQty(item.id, item.qty + 1)} style={{ width: 32, height: 32, border: 'none', background: '#F4F4F4', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Plus size={12} />
                  </button>
                </div>
                <p style={{ fontSize: 15, fontWeight: 700 }}>{(item.price * item.qty).toLocaleString('fr-FR')} FCFA</p>
              </div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div>
          <div style={{ background: 'white', borderRadius: 20, padding: 28, boxShadow: '0 4px 20px rgba(0,0,0,0.08)', position: 'sticky', top: 90 }}>
            <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 24, display: 'flex', alignItems: 'center', gap: 8 }}>
              <ShoppingBag size={20} color="#017BFE" /> Récapitulatif
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: '#555' }}>
                <span>Sous-total</span><span style={{ fontWeight: 600 }}>{total.toLocaleString('fr-FR')} FCFA</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: '#555' }}>
                <span>Livraison</span>
                <span style={{ fontWeight: 600, color: shipping === 0 ? '#02AB84' : '#232323' }}>
                  {shipping === 0 ? 'Gratuite 🎉' : `${shipping.toLocaleString('fr-FR')} FCFA`}
                </span>
              </div>
              {shipping > 0 && (
                <p style={{ fontSize: 11, color: '#888', background: '#FFF3E0', borderRadius: 8, padding: '6px 10px' }}>
                  Plus que {(15000 - total).toLocaleString('fr-FR')} FCFA pour la livraison gratuite !
                </p>
              )}
            </div>
            <div style={{ borderTop: '2px solid #F4F4F4', paddingTop: 16, marginBottom: 20, display: 'flex', justifyContent: 'space-between', fontSize: 18, fontWeight: 800 }}>
              <span>Total</span><span style={{ color: '#017BFE' }}>{finalTotal.toLocaleString('fr-FR')} FCFA</span>
            </div>

            <div style={{ marginBottom: 20 }}>
              <input placeholder="Code promo" style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 12, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
            </div>

            <Link to="/commande" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, background: '#017BFE', color: 'white', borderRadius: 28, padding: '16px', fontWeight: 700, fontSize: 15, textDecoration: 'none', marginBottom: 12 }}>
              Passer la commande <ArrowRight size={18} />
            </Link>
            <Link to="/catalogue" style={{ display: 'block', textAlign: 'center', color: '#666', textDecoration: 'none', fontSize: 13 }}>
              ← Continuer les achats
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
