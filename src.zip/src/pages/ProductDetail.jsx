import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, ShoppingCart, Heart, ChevronRight, Check, Truck, Shield, RefreshCw } from 'lucide-react';
import { MOCK_PRODUCTS } from '../utils/constants';
import { useCart } from '../context/AppContext';
import ProductCard from '../components/ui/ProductCard';

const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

export default function ProductDetail() {
  const { id } = useParams();
  const { addItem } = useCart();
  const product = MOCK_PRODUCTS.find(p => p.id === parseInt(id)) || MOCK_PRODUCTS[0];
  const related = MOCK_PRODUCTS.filter(p => p.id !== product.id).slice(0, 4);

  const [selectedSize, setSelectedSize] = useState('M');
  const [qty, setQty] = useState(1);
  const [liked, setLiked] = useState(false);
  const [added, setAdded] = useState(false);
  const [activeTab, setActiveTab] = useState('description');
  const [selectedImg, setSelectedImg] = useState(0);
  const images = [product.image, product.image, product.image];

  const handleAdd = () => {
    addItem({ ...product, size: selectedSize }, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const REVIEWS = [
    { name: 'Ayo K.', rating: 5, date: '12 mars 2025', text: 'Super qualité ! Exactement comme sur la photo. Livraison rapide.' },
    { name: 'Fatou M.', rating: 4, date: '5 mars 2025', text: 'Très beau produit, la personnalisation est top. Je recommande !' },
  ];

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '40px 24px' }}>
      {/* Breadcrumb */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: '#888', marginBottom: 32 }}>
        <Link to="/" style={{ color: '#888', textDecoration: 'none' }}>Accueil</Link>
        <ChevronRight size={14} />
        <Link to="/catalogue" style={{ color: '#888', textDecoration: 'none' }}>Catalogue</Link>
        <ChevronRight size={14} />
        <span style={{ color: '#017BFE', fontWeight: 600 }}>{product.name}</span>
      </div>

      {/* Main */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, marginBottom: 80 }}>
        {/* Images */}
        <div>
          <div style={{ borderRadius: 20, overflow: 'hidden', background: '#F9F9F9', height: 440, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16, position: 'relative' }}>
            <img src={images[selectedImg]} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            <button onClick={() => setLiked(!liked)} style={{ position: 'absolute', top: 16, right: 16, background: 'white', border: 'none', borderRadius: '50%', width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', boxShadow: '0 2px 8px rgba(0,0,0,0.12)' }}>
              <Heart size={18} fill={liked ? '#ef4444' : 'none'} stroke={liked ? '#ef4444' : '#999'} />
            </button>
          </div>
          <div style={{ display: 'flex', gap: 12 }}>
            {images.map((img, i) => (
              <div key={i} onClick={() => setSelectedImg(i)} style={{ width: 80, height: 80, borderRadius: 12, overflow: 'hidden', border: `2px solid ${selectedImg === i ? '#017BFE' : '#eee'}`, cursor: 'pointer' }}>
                <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
            ))}
          </div>
        </div>

        {/* Info */}
        <div>
          {product.isNew && <span style={{ background: '#017BFE', color: 'white', fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 20, display: 'inline-block', marginBottom: 12 }}>NOUVEAU</span>}
          <h1 style={{ fontSize: 32, fontWeight: 800, marginBottom: 12, fontFamily: "'Mochiy Pop One', sans-serif" }}>
            <span>{product.name.split(' ')[0]} </span>
            <span style={{ color: '#017BFE' }}>{product.name.split(' ').slice(1).join(' ')}</span>
          </h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20 }}>
            {[1,2,3,4,5].map(s => <Star key={s} size={16} fill={s <= Math.round(product.rating) ? '#E6B95E' : '#ddd'} stroke={s <= Math.round(product.rating) ? '#E6B95E' : '#ddd'} />)}
            <span style={{ fontSize: 14, color: '#666' }}>{product.rating?.toFixed(1)} (24 avis)</span>
          </div>
          <p style={{ fontSize: 32, fontWeight: 800, color: '#017BFE', marginBottom: 24 }}>{product.price?.toLocaleString('fr-FR')} FCFA</p>

          {/* Size */}
          <div style={{ marginBottom: 24 }}>
            <p style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>Taille : <span style={{ color: '#017BFE' }}>{selectedSize}</span></p>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {SIZES.map(s => (
                <button key={s} onClick={() => setSelectedSize(s)} style={{ width: 48, height: 48, borderRadius: 12, border: `2px solid ${selectedSize === s ? '#017BFE' : '#e5e7eb'}`, background: selectedSize === s ? '#017BFE' : 'white', color: selectedSize === s ? 'white' : '#232323', fontWeight: 700, cursor: 'pointer', fontSize: 14, transition: 'all 0.2s' }}>{s}</button>
              ))}
            </div>
          </div>

          {/* Qty */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 28 }}>
            <p style={{ fontSize: 14, fontWeight: 700 }}>Quantité :</p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 0, border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' }}>
              <button onClick={() => setQty(Math.max(1, qty - 1))} style={{ width: 40, height: 40, border: 'none', background: '#F4F4F4', cursor: 'pointer', fontSize: 18, fontWeight: 700 }}>−</button>
              <span style={{ width: 48, textAlign: 'center', fontSize: 16, fontWeight: 700 }}>{qty}</span>
              <button onClick={() => setQty(qty + 1)} style={{ width: 40, height: 40, border: 'none', background: '#F4F4F4', cursor: 'pointer', fontSize: 18, fontWeight: 700 }}>+</button>
            </div>
          </div>

          {/* CTA */}
          <div style={{ display: 'flex', gap: 12, marginBottom: 32 }}>
            <button onClick={handleAdd} style={{ flex: 1, background: added ? '#02AB84' : '#017BFE', color: 'white', border: 'none', borderRadius: 28, padding: '16px', fontWeight: 700, fontSize: 15, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, transition: 'background 0.3s' }}>
              {added ? <><Check size={18} /> Ajouté au panier</> : <><ShoppingCart size={18} /> Ajouter au panier</>}
            </button>
            <Link to="/personnalisation" style={{ flex: 1, border: '2px solid #017BFE', color: '#017BFE', borderRadius: 28, padding: '16px', fontWeight: 700, fontSize: 14, textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              🎨 Personnaliser
            </Link>
          </div>

          {/* Trust badges */}
          <div style={{ display: 'flex', gap: 20 }}>
            {[
              { icon: Truck, label: 'Livraison 3-7 jours' },
              { icon: Shield, label: 'Paiement sécurisé' },
              { icon: RefreshCw, label: 'Retour facile' },
            ].map((b, i) => (
              <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, flex: 1, background: '#F4F4F4', borderRadius: 12, padding: 12, textAlign: 'center' }}>
                <b.icon size={20} color="#017BFE" />
                <span style={{ fontSize: 11, fontWeight: 600, color: '#555' }}>{b.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ borderBottom: '2px solid #F4F4F4', display: 'flex', gap: 32, marginBottom: 32 }}>
        {['description', 'avis', 'livraison'].map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 15, fontWeight: 700, paddingBottom: 16, borderBottom: activeTab === tab ? '3px solid #017BFE' : '3px solid transparent', color: activeTab === tab ? '#017BFE' : '#888', textTransform: 'capitalize' }}>
            {tab === 'avis' ? `Avis (${REVIEWS.length})` : tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {activeTab === 'description' && (
        <div style={{ maxWidth: 700, color: '#555', lineHeight: 1.8, fontSize: 15 }}>
          <p style={{ marginBottom: 16 }}>Ce produit est fabriqué avec des matériaux de haute qualité, garantissant durabilité et confort. L'impression est réalisée avec des techniques modernes pour un rendu impeccable.</p>
          <ul style={{ paddingLeft: 20 }}>
            <li>Matière : 100% Coton bio</li>
            <li>Impression : Sublimation thermique</li>
            <li>Entretien : Lavage à 30°C</li>
            <li>Fabriqué au Bénin</li>
          </ul>
        </div>
      )}

      {activeTab === 'avis' && (
        <div style={{ maxWidth: 700 }}>
          {REVIEWS.map((r, i) => (
            <div key={i} style={{ background: 'white', borderRadius: 16, padding: 24, marginBottom: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: '50%', background: '#CBF6FD', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: '#017BFE' }}>{r.name[0]}</div>
                <div>
                  <p style={{ fontWeight: 700, fontSize: 14 }}>{r.name}</p>
                  <div style={{ display: 'flex', gap: 2 }}>
                    {[1,2,3,4,5].map(s => <Star key={s} size={12} fill={s <= r.rating ? '#E6B95E' : '#ddd'} stroke="none" />)}
                    <span style={{ fontSize: 11, color: '#999', marginLeft: 4 }}>{r.date}</span>
                  </div>
                </div>
              </div>
              <p style={{ fontSize: 14, color: '#555' }}>{r.text}</p>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'livraison' && (
        <div style={{ maxWidth: 700, color: '#555', lineHeight: 1.8, fontSize: 15 }}>
          <p><strong>Délai de livraison :</strong> 3 à 7 jours ouvrés</p>
          <p><strong>Cotonou & environs :</strong> 24 à 48h</p>
          <p><strong>Frais de livraison :</strong> Gratuit à partir de 15 000 FCFA</p>
          <p><strong>Modes de paiement :</strong> Mobile Money (MTN, Moov, Celtiis), Carte bancaire</p>
        </div>
      )}

      {/* Related */}
      <div style={{ marginTop: 80 }}>
        <h2 style={{ fontSize: 24, fontWeight: 800, marginBottom: 24 }}>Produits similaires</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 20 }}>
          {related.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </div>
  );
}
