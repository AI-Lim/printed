import { useState } from 'react';
import AdminLayout from './AdminLayout';
import { Search, Eye, CheckCircle, XCircle } from 'lucide-react';

const ORDERS = Array.from({ length: 20 }, (_, i) => ({
  id: `PRT-${String(1000 + i).padStart(6, '0')}`,
  customer: ['Ayo Kossou', 'Fatou Mensah', 'Koffi Diabate', 'Marie Adjaho', 'Jean Agossa'][i % 5],
  product: ['T-Shirt Zoro', 'Mug Anime', 'Pack Entreprise', 'Sweat Otaku', 'Coque Phone'][i % 5],
  amount: [10000, 8000, 150000, 15000, 5000][i % 5],
  status: ['Livré', 'En production', 'Expédié', 'En attente', 'Annulé'][i % 5],
  date: `${22 - i} mars 2025`,
  payment: ['Mobile Money', 'Carte Bancaire', 'Mobile Money'][i % 3],
}));

const STATUS_COLORS = { 'Livré': '#02AB84', 'En production': '#E6B95E', 'Expédié': '#017BFE', 'En attente': '#888', 'Annulé': '#ef4444' };

export default function AdminOrders() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('Tous');
  const [selected, setSelected] = useState(null);

  const statuses = ['Tous', 'En attente', 'En production', 'Expédié', 'Livré', 'Annulé'];
  const filtered = ORDERS.filter(o => {
    const matchSearch = o.customer.toLowerCase().includes(search.toLowerCase()) || o.id.includes(search);
    const matchStatus = statusFilter === 'Tous' || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <AdminLayout>
      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 24 }}>Gestion des commandes</h1>

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16, marginBottom: 24 }}>
        {statuses.slice(1).map(s => (
          <div key={s} onClick={() => setStatusFilter(s)} style={{ background: 'white', borderRadius: 16, padding: 16, textAlign: 'center', cursor: 'pointer', border: `2px solid ${statusFilter === s ? STATUS_COLORS[s] : 'transparent'}`, boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
            <p style={{ fontSize: 24, fontWeight: 800, color: STATUS_COLORS[s] }}>{ORDERS.filter(o => o.status === s).length}</p>
            <p style={{ fontSize: 11, color: '#888', marginTop: 4 }}>{s}</p>
          </div>
        ))}
      </div>

      <div style={{ background: 'white', borderRadius: 20, padding: 24, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
        <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
            <Search size={16} color="#999" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher (ID, client...)"
              style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 20, padding: '10px 12px 10px 36px', fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {statuses.map(s => (
              <button key={s} onClick={() => setStatusFilter(s)} style={{ padding: '8px 16px', borderRadius: 20, border: 'none', cursor: 'pointer', fontSize: 12, fontWeight: 600, background: statusFilter === s ? '#017BFE' : '#F4F4F4', color: statusFilter === s ? 'white' : '#555' }}>{s}</button>
            ))}
          </div>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #F4F4F4' }}>
              {['ID', 'Client', 'Produit', 'Montant', 'Paiement', 'Statut', 'Date', 'Actions'].map(h => (
                <th key={h} style={{ textAlign: 'left', padding: '10px 12px', fontSize: 12, fontWeight: 700, color: '#888', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(order => (
              <tr key={order.id} style={{ borderBottom: '1px solid #F4F4F4', cursor: 'pointer' }}
                onMouseEnter={e => e.currentTarget.style.background = '#FAFAFA'}
                onMouseLeave={e => e.currentTarget.style.background = 'white'}>
                <td style={{ padding: '12px', fontSize: 13, fontWeight: 700, color: '#017BFE' }}>{order.id}</td>
                <td style={{ padding: '12px', fontSize: 13 }}>{order.customer}</td>
                <td style={{ padding: '12px', fontSize: 13, color: '#666' }}>{order.product}</td>
                <td style={{ padding: '12px', fontSize: 13, fontWeight: 700 }}>{order.amount.toLocaleString('fr-FR')} F</td>
                <td style={{ padding: '12px', fontSize: 12, color: '#666' }}>{order.payment}</td>
                <td style={{ padding: '12px' }}>
                  <select defaultValue={order.status} style={{ border: 'none', background: STATUS_COLORS[order.status] + '20', color: STATUS_COLORS[order.status], padding: '4px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700, cursor: 'pointer', outline: 'none' }}>
                    {statuses.slice(1).map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </td>
                <td style={{ padding: '12px', fontSize: 12, color: '#aaa' }}>{order.date}</td>
                <td style={{ padding: '12px' }}>
                  <button style={{ background: '#E5F4FF', border: 'none', borderRadius: 10, padding: '6px 10px', cursor: 'pointer' }}>
                    <Eye size={14} color="#017BFE" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p style={{ fontSize: 13, color: '#888', marginTop: 16 }}>{filtered.length} commande{filtered.length > 1 ? 's' : ''}</p>
      </div>
    </AdminLayout>
  );
}
