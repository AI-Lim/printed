import { useState } from 'react';
import AdminLayout from './AdminLayout';
import { Search, UserX, Shield } from 'lucide-react';

const USERS = Array.from({ length: 15 }, (_, i) => ({
  id: i + 1, name: ['Ayo Kossou', 'Fatou Mensah', 'Koffi Diabate', 'Marie Adjaho', 'Jean Agossa', 'Alice Dossou', 'Paul Noukpo', 'Emma Ahyi', 'Marc Zinsou', 'Clara Adjovi', 'Simon Ahounou', 'Laure Dovonou', 'Didier Sossa', 'Yemi Hodonou', 'Rach Agbo'][i],
  email: `user${i + 1}@example.com`, role: i === 0 ? 'admin' : 'client',
  orders: Math.floor(Math.random() * 10), joined: `${Math.floor(Math.random() * 28) + 1} janv. 2025`,
  status: i % 7 === 0 ? 'Suspendu' : 'Actif',
}));

export default function AdminUsers() {
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('Tous');
  const filtered = USERS.filter(u => {
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) || u.email.includes(search);
    const matchRole = roleFilter === 'Tous' || u.role === roleFilter;
    return matchSearch && matchRole;
  });

  return (
    <AdminLayout>
      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 24 }}>Gestion des utilisateurs</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'Total utilisateurs', value: USERS.length, color: '#017BFE' },
          { label: 'Clients actifs', value: USERS.filter(u => u.status === 'Actif' && u.role === 'client').length, color: '#02AB84' },
          { label: 'Administrateurs', value: USERS.filter(u => u.role === 'admin').length, color: '#E6B95E' },
        ].map((s, i) => (
          <div key={i} style={{ background: 'white', borderRadius: 16, padding: 20, textAlign: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
            <p style={{ fontSize: 28, fontWeight: 800, color: s.color }}>{s.value}</p>
            <p style={{ fontSize: 13, color: '#888', marginTop: 4 }}>{s.label}</p>
          </div>
        ))}
      </div>

      <div style={{ background: 'white', borderRadius: 20, padding: 24, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
        <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
            <Search size={16} color="#999" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Nom, email..."
              style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 20, padding: '10px 12px 10px 36px', fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
          </div>
          {['Tous', 'admin', 'client'].map(r => (
            <button key={r} onClick={() => setRoleFilter(r)} style={{ padding: '8px 20px', borderRadius: 20, border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600, background: roleFilter === r ? '#017BFE' : '#F4F4F4', color: roleFilter === r ? 'white' : '#555', textTransform: 'capitalize' }}>{r}</button>
          ))}
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #F4F4F4' }}>
              {['Utilisateur', 'Email', 'Rôle', 'Commandes', 'Statut', 'Inscrit le', 'Actions'].map(h => (
                <th key={h} style={{ textAlign: 'left', padding: '10px 12px', fontSize: 12, fontWeight: 700, color: '#888', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(user => (
              <tr key={user.id} style={{ borderBottom: '1px solid #F4F4F4' }}
                onMouseEnter={e => e.currentTarget.style.background = '#FAFAFA'}
                onMouseLeave={e => e.currentTarget.style.background = 'white'}>
                <td style={{ padding: '12px', display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#017BFE', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 700, fontSize: 14 }}>{user.name[0]}</div>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>{user.name}</span>
                </td>
                <td style={{ padding: '12px', fontSize: 13, color: '#666' }}>{user.email}</td>
                <td style={{ padding: '12px' }}>
                  <span style={{ background: user.role === 'admin' ? '#FFF3E0' : '#E5F4FF', color: user.role === 'admin' ? '#E6B95E' : '#017BFE', padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 4, width: 'fit-content' }}>
                    {user.role === 'admin' && <Shield size={10} />}{user.role}
                  </span>
                </td>
                <td style={{ padding: '12px', fontSize: 13, fontWeight: 700 }}>{user.orders}</td>
                <td style={{ padding: '12px' }}>
                  <span style={{ background: user.status === 'Actif' ? '#E5F9F4' : '#FEF2F2', color: user.status === 'Actif' ? '#02AB84' : '#ef4444', padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700 }}>{user.status}</span>
                </td>
                <td style={{ padding: '12px', fontSize: 12, color: '#aaa' }}>{user.joined}</td>
                <td style={{ padding: '12px' }}>
                  <button title="Suspendre" style={{ background: '#FEF2F2', border: 'none', borderRadius: 10, padding: '6px 10px', cursor: 'pointer' }}>
                    <UserX size={14} color="#ef4444" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
