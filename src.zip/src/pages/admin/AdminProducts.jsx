import { useState } from 'react';
import AdminLayout from './AdminLayout';
import { Plus, Search, Edit, Trash2, Eye } from 'lucide-react';
import { MOCK_PRODUCTS } from '../../utils/constants';

export default function AdminProducts() {
  const [products, setProducts] = useState(MOCK_PRODUCTS);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [form, setForm] = useState({ name: '', price: '', category: '', type: '' });

  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  const handleDelete = (id) => { if (window.confirm('Supprimer ce produit ?')) setProducts(prev => prev.filter(p => p.id !== id)); };
  const handleSubmit = (e) => { e.preventDefault(); setShowForm(false); setForm({ name: '', price: '', category: '', type: '' }); };

  return (
    <AdminLayout>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 800 }}>Gestion des produits</h1>
        <button onClick={() => setShowForm(true)} style={{ background: '#017BFE', color: 'white', border: 'none', borderRadius: 20, padding: '10px 20px', cursor: 'pointer', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
          <Plus size={16} /> Ajouter un produit
        </button>
      </div>

      {showForm && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div style={{ background: 'white', borderRadius: 24, padding: 40, width: 500, maxHeight: '90vh', overflowY: 'auto' }}>
            <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 24 }}>{editProduct ? 'Modifier' : 'Ajouter'} un produit</h2>
            <form onSubmit={handleSubmit}>
              {[
                { label: 'Nom du produit', key: 'name', placeholder: 'T-Shirt Otaku' },
                { label: 'Prix (FCFA)', key: 'price', type: 'number', placeholder: '10000' },
                { label: 'Catégorie', key: 'category', placeholder: 'otaku' },
                { label: 'Type', key: 'type', placeholder: 'T-Shirt' },
              ].map(f => (
                <div key={f.key} style={{ marginBottom: 16 }}>
                  <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>{f.label}</label>
                  <input type={f.type || 'text'} value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder} required
                    style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 12, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
                </div>
              ))}
              <div style={{ marginBottom: 24 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Image URL</label>
                <input type="url" placeholder="https://..." style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 12, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
              </div>
              <div style={{ display: 'flex', gap: 12 }}>
                <button type="button" onClick={() => setShowForm(false)} style={{ flex: 1, border: '1px solid #e5e7eb', background: 'white', borderRadius: 20, padding: '12px', cursor: 'pointer', fontWeight: 600 }}>Annuler</button>
                <button type="submit" style={{ flex: 1, background: '#017BFE', color: 'white', border: 'none', borderRadius: 20, padding: '12px', cursor: 'pointer', fontWeight: 700 }}>Enregistrer</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div style={{ background: 'white', borderRadius: 20, padding: 24, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
        <div style={{ marginBottom: 20, position: 'relative', maxWidth: 320 }}>
          <Search size={16} color="#999" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher un produit..."
            style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 20, padding: '10px 12px 10px 36px', fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #F4F4F4' }}>
              {['Image', 'Nom', 'Catégorie', 'Type', 'Prix', 'Note', 'Actions'].map(h => (
                <th key={h} style={{ textAlign: 'left', padding: '10px 12px', fontSize: 12, fontWeight: 700, color: '#888', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(p => (
              <tr key={p.id} style={{ borderBottom: '1px solid #F4F4F4' }} onMouseEnter={e => e.currentTarget.style.background = '#FAFAFA'} onMouseLeave={e => e.currentTarget.style.background = 'white'}>
                <td style={{ padding: '12px' }}>
                  <div style={{ width: 48, height: 48, borderRadius: 10, overflow: 'hidden', background: '#F4F4F4' }}>
                    <img src={p.image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} onError={e => e.target.style.display='none'} />
                  </div>
                </td>
                <td style={{ padding: '12px', fontSize: 14, fontWeight: 600 }}>{p.name}</td>
                <td style={{ padding: '12px', fontSize: 13, color: '#666' }}>{p.category}</td>
                <td style={{ padding: '12px', fontSize: 13, color: '#666' }}>{p.type}</td>
                <td style={{ padding: '12px', fontSize: 14, fontWeight: 700, color: '#017BFE' }}>{p.price?.toLocaleString('fr-FR')} F</td>
                <td style={{ padding: '12px', fontSize: 13 }}>⭐ {p.rating?.toFixed(1)}</td>
                <td style={{ padding: '12px' }}>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => { setEditProduct(p); setForm({ name: p.name, price: p.price, category: p.category, type: p.type }); setShowForm(true); }} style={{ background: '#E5F4FF', border: 'none', borderRadius: 10, padding: '6px 10px', cursor: 'pointer', display: 'flex', alignItems: 'center' }}><Edit size={14} color="#017BFE" /></button>
                    <button onClick={() => handleDelete(p.id)} style={{ background: '#FEF2F2', border: 'none', borderRadius: 10, padding: '6px 10px', cursor: 'pointer', display: 'flex', alignItems: 'center' }}><Trash2 size={14} color="#ef4444" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p style={{ fontSize: 13, color: '#888', marginTop: 16 }}>{filtered.length} produit{filtered.length > 1 ? 's' : ''} affiché{filtered.length > 1 ? 's' : ''}</p>
      </div>
    </AdminLayout>
  );
}
