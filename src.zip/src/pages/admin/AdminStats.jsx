import AdminLayout from './AdminLayout';

const MONTHLY = [
  { month: 'Oct', rev: 450000, orders: 45 }, { month: 'Nov', rev: 680000, orders: 68 },
  { month: 'Déc', rev: 920000, orders: 92 }, { month: 'Jan', rev: 750000, orders: 75 },
  { month: 'Fév', rev: 890000, orders: 89 }, { month: 'Mar', rev: 1250000, orders: 125 },
];
const maxRev = Math.max(...MONTHLY.map(m => m.rev));

export default function AdminStats() {
  return (
    <AdminLayout>
      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 24 }}>Statistiques & Rapports</h1>
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24 }}>
        {/* Revenue Chart */}
        <div style={{ background: 'white', borderRadius: 20, padding: 28, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
            <h2 style={{ fontSize: 18, fontWeight: 800 }}>Évolution du chiffre d'affaires</h2>
            <select style={{ border: '1px solid #e5e7eb', borderRadius: 20, padding: '6px 12px', fontSize: 13, outline: 'none', cursor: 'pointer' }}>
              <option>6 derniers mois</option><option>12 mois</option>
            </select>
          </div>
          {/* Bar chart */}
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16, height: 220, paddingBottom: 32, position: 'relative' }}>
            {MONTHLY.map((m, i) => (
              <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 10, color: '#888', fontWeight: 600 }}>{Math.round(m.rev / 1000)}k</span>
                <div style={{ width: '100%', borderRadius: '8px 8px 0 0', background: i === MONTHLY.length - 1 ? '#017BFE' : '#CBF6FD', height: `${(m.rev / maxRev) * 160}px`, transition: 'height 1s ease', position: 'relative' }}>
                  {i === MONTHLY.length - 1 && <div style={{ position: 'absolute', top: -20, left: '50%', transform: 'translateX(-50%)', background: '#017BFE', color: 'white', borderRadius: 10, padding: '2px 8px', fontSize: 10, fontWeight: 700, whiteSpace: 'nowrap' }}>Ce mois</div>}
                </div>
                <span style={{ fontSize: 12, color: '#888' }}>{m.month}</span>
              </div>
            ))}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Top categories */}
          <div style={{ background: 'white', borderRadius: 20, padding: 24, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
            <h3 style={{ fontSize: 16, fontWeight: 800, marginBottom: 20 }}>Top catégories</h3>
            {[
              { name: 'Otaku 🎌', pct: 35, color: '#017BFE' },
              { name: 'Nature 🌿', pct: 22, color: '#02AB84' },
              { name: 'Motivation 💪', pct: 18, color: '#E6B95E' },
              { name: 'Gaming 🎮', pct: 15, color: '#8B5CF6' },
              { name: 'Autres', pct: 10, color: '#e5e7eb' },
            ].map((c, i) => (
              <div key={i} style={{ marginBottom: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13 }}>
                  <span style={{ fontWeight: 600 }}>{c.name}</span>
                  <span style={{ color: '#888' }}>{c.pct}%</span>
                </div>
                <div style={{ height: 8, background: '#F4F4F4', borderRadius: 4 }}>
                  <div style={{ height: '100%', width: `${c.pct}%`, background: c.color, borderRadius: 4 }} />
                </div>
              </div>
            ))}
          </div>

          {/* Payment methods */}
          <div style={{ background: 'white', borderRadius: 20, padding: 24, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
            <h3 style={{ fontSize: 16, fontWeight: 800, marginBottom: 20 }}>Moyens de paiement</h3>
            {[
              { name: 'MTN Mobile Money', pct: 58, color: '#F59E0B' },
              { name: 'Moov Money', pct: 24, color: '#10B981' },
              { name: 'Carte bancaire', pct: 12, color: '#232323' },
              { name: 'Celtiis', pct: 6, color: '#6366F1' },
            ].map((m, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <div style={{ width: 12, height: 12, borderRadius: '50%', background: m.color, flexShrink: 0 }} />
                <span style={{ flex: 1, fontSize: 13 }}>{m.name}</span>
                <span style={{ fontSize: 13, fontWeight: 700 }}>{m.pct}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Table */}
      <div style={{ background: 'white', borderRadius: 20, padding: 28, boxShadow: '0 2px 12px rgba(0,0,0,0.04)', marginTop: 24 }}>
        <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Rapport mensuel détaillé</h2>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #F4F4F4' }}>
              {['Mois', 'Commandes', 'Chiffre d\'affaires', 'Panier moyen', 'Croissance'].map(h => (
                <th key={h} style={{ textAlign: 'left', padding: '10px 12px', fontSize: 12, fontWeight: 700, color: '#888', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {MONTHLY.map((m, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #F4F4F4' }}
                onMouseEnter={e => e.currentTarget.style.background = '#FAFAFA'}
                onMouseLeave={e => e.currentTarget.style.background = 'white'}>
                <td style={{ padding: '12px', fontSize: 14, fontWeight: 700 }}>{m.month} 2025</td>
                <td style={{ padding: '12px', fontSize: 14 }}>{m.orders}</td>
                <td style={{ padding: '12px', fontSize: 14, fontWeight: 700, color: '#017BFE' }}>{m.rev.toLocaleString('fr-FR')} FCFA</td>
                <td style={{ padding: '12px', fontSize: 14 }}>{Math.round(m.rev / m.orders).toLocaleString('fr-FR')} FCFA</td>
                <td style={{ padding: '12px' }}>
                  {i > 0 && (
                    <span style={{ color: m.rev >= MONTHLY[i-1].rev ? '#02AB84' : '#ef4444', fontWeight: 700, fontSize: 13 }}>
                      {m.rev >= MONTHLY[i-1].rev ? '↑' : '↓'} {Math.abs(Math.round((m.rev - MONTHLY[i-1].rev) / MONTHLY[i-1].rev * 100))}%
                    </span>
                  )}
                  {i === 0 && <span style={{ color: '#888', fontSize: 13 }}>—</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
