import AdminLayout from './AdminLayout';
import { TrendingUp, ShoppingBag, Users, Package, ArrowUp } from 'lucide-react';

const STATS = [
  { label: 'Chiffre d\'affaires', value: '1 250 000 FCFA', change: '+12%', icon: TrendingUp, color: '#017BFE' },
  { label: 'Commandes', value: '148', change: '+8%', icon: ShoppingBag, color: '#02AB84' },
  { label: 'Clients', value: '312', change: '+5%', icon: Users, color: '#E6B95E' },
  { label: 'Produits actifs', value: '64', change: '+3', icon: Package, color: '#8B5CF6' },
];

const RECENT_ORDERS = [
  { id: 'PRT-001', customer: 'Ayo Kossou', product: 'T-Shirt Zoro', amount: 10000, status: 'Livré', date: 'Auj. 14:22' },
  { id: 'PRT-002', customer: 'Fatou Mensah', product: 'Mug Personnalisé', amount: 8000, status: 'En production', date: 'Auj. 11:05' },
  { id: 'PRT-003', customer: 'Koffi Diabate', product: 'Pack Entreprise', amount: 150000, status: 'Expédié', date: 'Hier 16:30' },
  { id: 'PRT-004', customer: 'Marie Adjaho', product: 'Sweat Otaku', amount: 15000, status: 'En attente', date: 'Hier 10:00' },
  { id: 'PRT-005', customer: 'Jean Agossa', product: 'Coque Phone', amount: 5000, status: 'Livré', date: '22 mars' },
];

const STATUS_COLORS = { 'Livré': '#02AB84', 'En production': '#E6B95E', 'Expédié': '#017BFE', 'En attente': '#888', 'Annulé': '#ef4444' };

export default function Dashboard() {
  return (
    <AdminLayout>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20, marginBottom: 32 }}>
        {STATS.map((s, i) => (
          <div key={i} style={{ background: 'white', borderRadius: 20, padding: 24, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: s.color + '20', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <s.icon size={22} color={s.color} />
              </div>
              <span style={{ fontSize: 12, fontWeight: 700, color: '#02AB84', background: '#E5F9F4', padding: '3px 8px', borderRadius: 20, display: 'flex', alignItems: 'center', gap: 2 }}>
                <ArrowUp size={10} />{s.change}
              </span>
            </div>
            <p style={{ fontSize: 24, fontWeight: 800, marginBottom: 4 }}>{s.value}</p>
            <p style={{ fontSize: 13, color: '#888' }}>{s.label}</p>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24 }}>
        {/* Recent orders */}
        <div style={{ background: 'white', borderRadius: 20, padding: 24, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <h2 style={{ fontSize: 18, fontWeight: 800 }}>Commandes récentes</h2>
            <button style={{ background: 'none', border: 'none', color: '#017BFE', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>Voir tout →</button>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #F4F4F4' }}>
                {['ID', 'Client', 'Produit', 'Montant', 'Statut', 'Date'].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '8px 12px', fontSize: 12, fontWeight: 700, color: '#888', textTransform: 'uppercase' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {RECENT_ORDERS.map(order => (
                <tr key={order.id} style={{ borderBottom: '1px solid #F4F4F4' }}>
                  <td style={{ padding: '12px 12px', fontSize: 13, fontWeight: 700, color: '#017BFE' }}>{order.id}</td>
                  <td style={{ padding: '12px 12px', fontSize: 13 }}>{order.customer}</td>
                  <td style={{ padding: '12px 12px', fontSize: 13, color: '#666' }}>{order.product}</td>
                  <td style={{ padding: '12px 12px', fontSize: 13, fontWeight: 700 }}>{order.amount.toLocaleString('fr-FR')} F</td>
                  <td style={{ padding: '12px 12px' }}>
                    <span style={{ background: STATUS_COLORS[order.status] + '20', color: STATUS_COLORS[order.status], padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700 }}>{order.status}</span>
                  </td>
                  <td style={{ padding: '12px 12px', fontSize: 12, color: '#aaa' }}>{order.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Quick stats */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ background: 'white', borderRadius: 20, padding: 24, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
            <h2 style={{ fontSize: 16, fontWeight: 800, marginBottom: 16 }}>Top Produits</h2>
            {[
              { name: 'T-Shirt Zoro', sold: 48, percent: 80 },
              { name: 'Mug Anime', sold: 36, percent: 60 },
              { name: 'Sweat Nature', sold: 24, percent: 40 },
              { name: 'Sneakers Custom', sold: 18, percent: 30 },
            ].map((p, i) => (
              <div key={i} style={{ marginBottom: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{p.name}</span>
                  <span style={{ fontSize: 12, color: '#888' }}>{p.sold} ventes</span>
                </div>
                <div style={{ height: 6, background: '#F4F4F4', borderRadius: 3 }}>
                  <div style={{ height: '100%', width: `${p.percent}%`, background: '#017BFE', borderRadius: 3, transition: 'width 1s ease' }} />
                </div>
              </div>
            ))}
          </div>
          <div style={{ background: 'linear-gradient(135deg, #017BFE, #00C2FF)', borderRadius: 20, padding: 24, color: 'white' }}>
            <h3 style={{ fontSize: 16, fontWeight: 800, marginBottom: 8 }}>Ce mois</h3>
            <p style={{ fontSize: 32, fontWeight: 800 }}>1 250 000</p>
            <p style={{ fontSize: 13, opacity: 0.8 }}>FCFA de revenus</p>
            <div style={{ height: 2, background: 'rgba(255,255,255,0.3)', margin: '16px 0' }} />
            <p style={{ fontSize: 13, opacity: 0.9 }}>↑ +12% vs mois dernier</p>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
