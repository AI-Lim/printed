import { useState } from 'react';
import AdminLayout from './AdminLayout';
import { Save } from 'lucide-react';

export default function AdminSettings() {
  const [saved, setSaved] = useState(false);
  const handleSave = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  return (
    <AdminLayout>
      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 24 }}>Paramètres de la plateforme</h1>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* General */}
        <div style={{ background: 'white', borderRadius: 20, padding: 28, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Informations générales</h2>
          {[
            { label: 'Nom du site', value: 'Printed' },
            { label: 'Email contact', value: 'mailprinted@gmail.com' },
            { label: 'Téléphone', value: '+229 01 00 00 00 00' },
            { label: 'Adresse', value: 'Abomey-Calavi, Bénin' },
          ].map(f => (
            <div key={f.label} style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>{f.label}</label>
              <input defaultValue={f.value} style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 12, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
            </div>
          ))}
        </div>

        {/* Delivery */}
        <div style={{ background: 'white', borderRadius: 20, padding: 28, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Livraison</h2>
          {[
            { label: 'Frais de livraison standard (FCFA)', value: '2000' },
            { label: 'Montant pour livraison gratuite (FCFA)', value: '15000' },
            { label: 'Délai standard (jours)', value: '3-7' },
            { label: 'Délai express Cotonou (heures)', value: '24-48' },
          ].map(f => (
            <div key={f.label} style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>{f.label}</label>
              <input defaultValue={f.value} style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 12, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
            </div>
          ))}
        </div>

        {/* Payment */}
        <div style={{ background: 'white', borderRadius: 20, padding: 28, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Paiement</h2>
          {['MTN Mobile Money', 'Moov Money', 'Celtiis', 'Carte bancaire (Stripe)'].map(m => (
            <div key={m} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid #f0f0f0' }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>{m}</span>
              <div style={{ width: 48, height: 28, borderRadius: 28, background: '#017BFE', position: 'relative', cursor: 'pointer' }}>
                <div style={{ position: 'absolute', right: 4, top: 4, width: 20, height: 20, borderRadius: '50%', background: 'white' }} />
              </div>
            </div>
          ))}
        </div>

        {/* Notifications */}
        <div style={{ background: 'white', borderRadius: 20, padding: 28, boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>Notifications automatiques</h2>
          {[
            'Email de confirmation de commande',
            'SMS de suivi d\'expédition',
            'Email de livraison',
            'Newsletter hebdomadaire',
            'Alertes de stock bas',
          ].map(n => (
            <div key={n} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid #f0f0f0' }}>
              <span style={{ fontSize: 14 }}>{n}</span>
              <div style={{ width: 48, height: 28, borderRadius: 28, background: '#017BFE', position: 'relative', cursor: 'pointer' }}>
                <div style={{ position: 'absolute', right: 4, top: 4, width: 20, height: 20, borderRadius: '50%', background: 'white' }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <button onClick={handleSave} style={{ marginTop: 24, background: saved ? '#02AB84' : '#017BFE', color: 'white', border: 'none', borderRadius: 28, padding: '14px 36px', fontWeight: 700, cursor: 'pointer', fontSize: 15, display: 'flex', alignItems: 'center', gap: 8, transition: 'background 0.3s' }}>
        <Save size={18} />{saved ? 'Enregistré ✓' : 'Enregistrer les modifications'}
      </button>
    </AdminLayout>
  );
}
