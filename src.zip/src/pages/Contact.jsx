import { useState } from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';

export default function Contact() {
  const [form, setForm] = useState({ nom: '', tel: '', email: '', interet: '', sujet: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => { e.preventDefault(); setSent(true); };

  return (
    <div>
      <div style={{ background: 'linear-gradient(135deg, #F4F4F4 0%, #CBF6FD 100%)', padding: '60px 24px', textAlign: 'center' }}>
        <h1 style={{ fontSize: 40, fontWeight: 800, color: '#017BFE' }}>Contactez-nous</h1>
        <p style={{ color: '#555', marginTop: 8 }}>Notre équipe est disponible pour vous répondre</p>
      </div>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '60px 24px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48 }}>
        {/* Form */}
        <div style={{ background: 'white', borderRadius: 20, padding: 40, boxShadow: '0 4px 20px rgba(0,0,0,0.08)' }}>
          {sent ? (
            <div style={{ textAlign: 'center', padding: '40px 0' }}>
              <div style={{ fontSize: 60, marginBottom: 16 }}>✅</div>
              <h2 style={{ fontSize: 24, fontWeight: 800, color: '#02AB84' }}>Message envoyé !</h2>
              <p style={{ color: '#555', marginTop: 8 }}>Nous vous répondrons dans les plus brefs délais.</p>
              <button onClick={() => { setSent(false); setForm({ nom: '', tel: '', email: '', interet: '', sujet: '', message: '' }); }}
                style={{ marginTop: 24, background: '#017BFE', color: 'white', border: 'none', borderRadius: 28, padding: '12px 28px', cursor: 'pointer', fontWeight: 600 }}>
                Nouveau message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <h2 style={{ fontSize: 24, fontWeight: 800, marginBottom: 24 }}>Envoyez-nous un message</h2>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                {[
                  { label: 'Nom', key: 'nom', placeholder: 'Votre nom' },
                  { label: 'Téléphone', key: 'tel', placeholder: '+229 00 000 000' },
                  { label: 'Adresse Email', key: 'email', type: 'email', placeholder: 'votre@email.com' },
                  { label: 'Intérêts', key: 'interet', type: 'select' },
                ].map(field => (
                  <div key={field.key}>
                    <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>{field.label}</label>
                    {field.type === 'select' ? (
                      <select value={form[field.key]} onChange={e => setForm(p => ({ ...p, [field.key]: e.target.value }))}
                        style={{ width: '100%', padding: '10px 12px', border: '1px solid #e5e7eb', borderRadius: 12, fontSize: 14, outline: 'none' }}>
                        <option value="">Choisir...</option>
                        <option>Commande</option><option>Personnalisation</option><option>Livraison</option><option>Partenariat</option><option>Autres</option>
                      </select>
                    ) : (
                      <input type={field.type || 'text'} value={form[field.key]} onChange={e => setForm(p => ({ ...p, [field.key]: e.target.value }))}
                        placeholder={field.placeholder}
                        style={{ width: '100%', padding: '10px 12px', border: '1px solid #e5e7eb', borderRadius: 12, fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
                    )}
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 16 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Sujet</label>
                <input value={form.sujet} onChange={e => setForm(p => ({ ...p, sujet: e.target.value }))} placeholder="Objet de votre message"
                  style={{ width: '100%', padding: '10px 12px', border: '1px solid #e5e7eb', borderRadius: 12, fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
              </div>
              <div style={{ marginTop: 16 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Message</label>
                <textarea value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))} rows={5}
                  placeholder="Votre message..." style={{ width: '100%', padding: '10px 12px', border: '1px solid #e5e7eb', borderRadius: 12, fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif', resize: 'vertical' }} />
              </div>
              <button type="submit" style={{ marginTop: 24, width: '100%', background: '#017BFE', color: 'white', border: 'none', borderRadius: 28, padding: '14px', fontWeight: 700, fontSize: 16, cursor: 'pointer', fontFamily: "'Mochiy Pop One', sans-serif" }}>
                Envoyer
              </button>
            </form>
          )}
        </div>

        {/* Info */}
        <div style={{ background: '#017BFE', borderRadius: 20, padding: 40, color: 'white' }}>
          <h2 style={{ fontSize: 24, fontWeight: 800, marginBottom: 32 }}>Nos coordonnées</h2>
          {[
            { icon: Phone, title: 'Appelez nous', info: '+229 01 00 00 00 00', sub: 'Lun - Sam, 8h - 18h' },
            { icon: Mail, title: 'Écrivez nous', info: 'mailprinted@gmail.com', sub: 'Réponse sous 24h' },
            { icon: MapPin, title: 'Visitez nous', info: 'Calavi, Bénin', sub: 'Abomey-Calavi, Atlantique' },
          ].map((item, i) => (
            <div key={i} style={{ display: 'flex', gap: 20, marginBottom: 32 }}>
              <div style={{ width: 50, height: 50, background: 'rgba(255,255,255,0.2)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <item.icon size={22} color="white" />
              </div>
              <div>
                <p style={{ fontWeight: 700, fontSize: 18, marginBottom: 4 }}>{item.title}</p>
                <p style={{ opacity: 0.9, marginBottom: 2 }}>{item.info}</p>
                <p style={{ opacity: 0.7, fontSize: 12 }}>{item.sub}</p>
              </div>
            </div>
          ))}
          <div style={{ marginTop: 40, padding: 24, background: 'rgba(255,255,255,0.15)', borderRadius: 16 }}>
            <p style={{ fontWeight: 700, marginBottom: 12 }}>Horaires d'ouverture</p>
            <p style={{ fontSize: 14, opacity: 0.9 }}>Lundi - Vendredi : 8h - 18h</p>
            <p style={{ fontSize: 14, opacity: 0.9 }}>Samedi : 9h - 16h</p>
            <p style={{ fontSize: 14, opacity: 0.9 }}>Dimanche : Fermé</p>
          </div>
        </div>
      </div>
    </div>
  );
}
