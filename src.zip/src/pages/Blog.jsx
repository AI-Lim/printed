import { Link } from 'react-router-dom';

const POSTS = [
  { id: 1, title: 'Les tendances de la mode personnalisée en 2025', category: 'Mode', date: '15 mars 2025', excerpt: 'Découvrez les grandes tendances qui vont marquer le monde de l\'impression à la demande cette année...', img: '🎨', readTime: '5 min', tag: 'Tendances' },
  { id: 2, title: 'Comment choisir le bon tissu pour vos t-shirts', category: 'Conseils', date: '8 mars 2025', excerpt: 'Coton, polyester, mixte... Votre choix de matière influence la qualité de l\'impression et le confort...', img: '👕', readTime: '4 min', tag: 'Guide' },
  { id: 3, title: '5 idées de cadeaux personnalisés pour la Saint-Valentin', category: 'Idées', date: '1 mars 2025', excerpt: 'Exprimez votre amour avec des cadeaux uniques : mugs, t-shirts, coques personnalisées...', img: '❤️', readTime: '3 min', tag: 'Cadeaux' },
  { id: 4, title: 'L\'impression à la demande au Bénin : état des lieux', category: 'Marché', date: '22 fév 2025', excerpt: 'Le marché de la personnalisation est en plein essor en Afrique de l\'Ouest. Printed se positionne...', img: '🌍', readTime: '6 min', tag: 'Marché' },
  { id: 5, title: 'Les meilleurs designs Otaku pour 2025', category: 'Gaming', date: '15 fév 2025', excerpt: 'Notre sélection des personnages et designs anime les plus demandés sur notre plateforme...', img: '🎌', readTime: '4 min', tag: 'Otaku' },
  { id: 6, title: 'DIY : Personnalisez votre intérieur avec Printed', category: 'DIY', date: '5 fév 2025', excerpt: 'Coussins, tableaux, textiles de maison... Comment créer un intérieur unique grâce à l\'impression...', img: '🏠', readTime: '5 min', tag: 'DIY' },
];

const CATEGORIES = ['Tous', 'Mode', 'Conseils', 'Idées', 'DIY', 'Marché', 'Gaming'];

export default function Blog() {
  const featured = POSTS[0];
  return (
    <div>
      <div style={{ background: 'linear-gradient(135deg, #F4F4F4 0%, #CBF6FD 100%)', padding: '60px 24px', textAlign: 'center', marginBottom: 48 }}>
        <h1 style={{ fontSize: 44, fontWeight: 800, color: '#017BFE', marginBottom: 12 }}>Le Blog Printed</h1>
        <p style={{ fontSize: 16, color: '#555', maxWidth: 500, margin: '0 auto' }}>Tendances, conseils, idées créatives — tout ce qu'il faut savoir sur la personnalisation</p>
      </div>

      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px 80px' }}>
        {/* Featured */}
        <div style={{ background: 'linear-gradient(135deg, #017BFE 0%, #00C2FF 100%)', borderRadius: 24, padding: '48px 40px', marginBottom: 48, display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'center', color: 'white' }}>
          <div>
            <span style={{ background: 'rgba(255,255,255,0.2)', padding: '4px 12px', borderRadius: 20, fontSize: 12, fontWeight: 700, display: 'inline-block', marginBottom: 16 }}>{featured.tag}</span>
            <h2 style={{ fontSize: 32, fontWeight: 800, marginBottom: 16, lineHeight: 1.3 }}>{featured.title}</h2>
            <p style={{ fontSize: 15, opacity: 0.9, marginBottom: 24, lineHeight: 1.7 }}>{featured.excerpt}</p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <span style={{ fontSize: 13, opacity: 0.8 }}>{featured.date}</span>
              <span style={{ fontSize: 13, opacity: 0.8 }}>· {featured.readTime} de lecture</span>
            </div>
          </div>
          <div style={{ fontSize: 100, opacity: 0.7 }}>{featured.img}</div>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 32 }}>
          {CATEGORIES.map(c => (
            <button key={c} style={{ padding: '8px 20px', borderRadius: 28, border: 'none', background: c === 'Tous' ? '#017BFE' : '#F4F4F4', color: c === 'Tous' ? 'white' : '#555', fontWeight: 600, cursor: 'pointer', fontSize: 14 }}>{c}</button>
          ))}
        </div>

        {/* Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 24 }}>
          {POSTS.slice(1).map(post => (
            <Link key={post.id} to={`/blog/${post.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
              <div style={{ background: 'white', borderRadius: 20, overflow: 'hidden', boxShadow: '0 4px 16px rgba(0,0,0,0.06)', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer' }}
                onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 8px 28px rgba(0,0,0,0.12)'; }}
                onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = '0 4px 16px rgba(0,0,0,0.06)'; }}>
                <div style={{ height: 160, background: 'linear-gradient(135deg, #CBF6FD, #E5F4FF)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 72 }}>
                  {post.img}
                </div>
                <div style={{ padding: 24 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                    <span style={{ background: '#E5F4FF', color: '#017BFE', padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700 }}>{post.tag}</span>
                    <span style={{ fontSize: 11, color: '#aaa' }}>{post.readTime}</span>
                  </div>
                  <h3 style={{ fontSize: 17, fontWeight: 800, marginBottom: 10, lineHeight: 1.4 }}>{post.title}</h3>
                  <p style={{ fontSize: 13, color: '#666', lineHeight: 1.7, marginBottom: 16 }}>{post.excerpt}</p>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 12, color: '#aaa' }}>{post.date}</span>
                    <span style={{ fontSize: 13, color: '#017BFE', fontWeight: 700 }}>Lire la suite →</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
