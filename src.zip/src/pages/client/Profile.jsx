import { useState } from 'react';
import { User, Package, Heart, Settings, Bell, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AppContext';
import { useNavigate, Link } from 'react-router-dom';
import { MOCK_PRODUCTS } from '../../utils/constants';

const ORDERS = [
  { id: 'PRT-001234', date: '12 mars 2025', status: 'Livré', total: 25000, items: 2 },
  { id: 'PRT-001100', date: '28 fév 2025', status: 'En production', total: 10000, items: 1 },
  { id: 'PRT-000987', date: '10 fév 2025', status: 'Expédié', total: 18000, items: 3 },
];

const STATUS_COLORS = { 'Livré': '#02AB84', 'En production': '#E6B95E', 'Expédié': '#017BFE', 'Annulé': '#ef4444' };

export default function Profile() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('profil');
  const [form, setForm] = useState({ name: user?.name || '', email: user?.email || '', phone: '' });

  if (!user) { navigate('/connexion'); return null; }

  const TABS = [
    { id: 'profil', label: 'Mon profil', icon: User },
    { id: 'commandes', label: 'Commandes', icon: Package },
    { id: 'favoris', label: 'Favoris', icon: Heart },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'parametres', label: 'Paramètres', icon: Settings },
  ];

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '40px 24px' }}>
      <h1 style={{ fontSize: 28, fontWeight: 800, marginBottom: 32 }}>Mon espace</h1>
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 32 }}>
        {/* Sidebar */}
        <div>
          <div style={{ background: 'white', borderRadius: 20, padding: 24, boxShadow: '0 4px 16px rgba(0,0,0,0.06)', marginBottom: 16, textAlign: 'center' }}>
            <div style={{ width: 72, height: 72, borderRadius: '50%', background: '#017BFE', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px', fontSize: 28, color: 'white', fontWeight: 800 }}>
              {user.name[0]}
            </div>
            <p style={{ fontWeight: 700, fontSize: 16 }}>{user.name}</p>
            <p style={{ fontSize: 13, color: '#888' }}>{user.email}</p>
            {user.role === 'admin' && (
              <Link to="/admin" style={{ display: 'inline-block', marginTop: 12, background: '#017BFE', color: 'white', padding: '6px 16px', borderRadius: 20, textDecoration: 'none', fontSize: 12, fontWeight: 700 }}>
                Panel Admin
              </Link>
            )}
          </div>
          <div style={{ background: 'white', borderRadius: 20, overflow: 'hidden', boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '14px 20px', border: 'none', background: tab === t.id ? '#E5F4FF' : 'white', cursor: 'pointer', borderLeft: `3px solid ${tab === t.id ? '#017BFE' : 'transparent'}`, fontSize: 14, fontWeight: tab === t.id ? 700 : 500, color: tab === t.id ? '#017BFE' : '#555', textAlign: 'left' }}>
                <t.icon size={16} />{t.label}
              </button>
            ))}
            <button onClick={() => { logout(); navigate('/'); }} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '14px 20px', border: 'none', background: 'white', cursor: 'pointer', borderLeft: '3px solid transparent', fontSize: 14, fontWeight: 500, color: '#ef4444', textAlign: 'left' }}>
              <LogOut size={16} /> Se déconnecter
            </button>
          </div>
        </div>

        {/* Content */}
        <div style={{ background: 'white', borderRadius: 20, padding: 32, boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}>
          {tab === 'profil' && (
            <>
              <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 24 }}>Mes informations</h2>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
                {[
                  { label: 'Nom complet', key: 'name' },
                  { label: 'Téléphone', key: 'phone' },
                  { label: 'Email', key: 'email', span: 2 },
                ].map(f => (
                  <div key={f.key} style={{ gridColumn: f.span ? `span ${f.span}` : undefined }}>
                    <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>{f.label}</label>
                    <input value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                      style={{ width: '100%', border: '1px solid #e5e7eb', borderRadius: 12, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
                  </div>
                ))}
              </div>
              <button style={{ marginTop: 24, background: '#017BFE', color: 'white', border: 'none', borderRadius: 28, padding: '12px 32px', fontWeight: 700, cursor: 'pointer', fontSize: 14 }}>
                Sauvegarder les modifications
              </button>
            </>
          )}

          {tab === 'commandes' && (
            <>
              <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 24 }}>Mes commandes</h2>
              {ORDERS.map(order => (
                <div key={order.id} style={{ border: '1px solid #e5e7eb', borderRadius: 16, padding: 20, marginBottom: 16 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                    <div>
                      <p style={{ fontWeight: 700, fontSize: 15 }}>{order.id}</p>
                      <p style={{ fontSize: 13, color: '#888' }}>{order.date} · {order.items} article{order.items > 1 ? 's' : ''}</p>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <span style={{ background: STATUS_COLORS[order.status] + '22', color: STATUS_COLORS[order.status], padding: '4px 12px', borderRadius: 20, fontSize: 12, fontWeight: 700 }}>{order.status}</span>
                      <p style={{ fontSize: 15, fontWeight: 800, color: '#017BFE', marginTop: 6 }}>{order.total.toLocaleString('fr-FR')} FCFA</p>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button style={{ background: '#017BFE', color: 'white', border: 'none', borderRadius: 20, padding: '6px 16px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Suivre</button>
                    <button style={{ background: 'none', border: '1px solid #e5e7eb', borderRadius: 20, padding: '6px 16px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Détails</button>
                  </div>
                </div>
              ))}
            </>
          )}

          {tab === 'favoris' && (
            <>
              <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 24 }}>Mes favoris</h2>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
                {MOCK_PRODUCTS.slice(0, 3).map(p => (
                  <Link key={p.id} to={`/produit/${p.id}`} style={{ textDecoration: 'none', color: 'inherit', border: '1px solid #e5e7eb', borderRadius: 16, overflow: 'hidden', display: 'block' }}>
                    <div style={{ height: 140, background: '#F4F4F4', overflow: 'hidden' }}>
                      <img src={p.image} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} onError={e => e.target.style.display='none'} />
                    </div>
                    <div style={{ padding: 12 }}>
                      <p style={{ fontWeight: 700, fontSize: 13, marginBottom: 4 }}>{p.name}</p>
                      <p style={{ fontSize: 13, color: '#017BFE', fontWeight: 700 }}>{p.price?.toLocaleString('fr-FR')} FCFA</p>
                    </div>
                  </Link>
                ))}
              </div>
            </>
          )}

          {tab === 'notifications' && (
            <>
              <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 24 }}>Notifications</h2>
              {[
                { title: 'Commande expédiée !', desc: 'Votre commande #PRT-001100 est en route.', time: 'Il y a 2h', read: false },
                { title: 'Nouveau code promo', desc: 'Profitez de -20% avec le code PRINTED20', time: 'Hier', read: true },
                { title: 'Commande livrée', desc: 'Votre commande #PRT-001234 a été livrée.', time: '12 mars', read: true },
              ].map((n, i) => (
                <div key={i} style={{ display: 'flex', gap: 14, padding: '16px 0', borderBottom: '1px solid #f0f0f0', opacity: n.read ? 0.7 : 1 }}>
                  <div style={{ width: 10, height: 10, borderRadius: '50%', background: n.read ? '#ddd' : '#017BFE', flexShrink: 0, marginTop: 6 }} />
                  <div style={{ flex: 1 }}>
                    <p style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{n.title}</p>
                    <p style={{ fontSize: 13, color: '#666' }}>{n.desc}</p>
                    <p style={{ fontSize: 11, color: '#aaa', marginTop: 4 }}>{n.time}</p>
                  </div>
                </div>
              ))}
            </>
          )}

          {tab === 'parametres' && (
            <>
              <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 24 }}>Paramètres du compte</h2>
              {[
                { label: 'Notifications email', desc: 'Recevoir des emails pour les commandes' },
                { label: 'Notifications SMS', desc: 'Recevoir des SMS de suivi' },
                { label: 'Newsletter', desc: 'Offres et nouveautés Printed' },
              ].map((s, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 0', borderBottom: '1px solid #f0f0f0' }}>
                  <div>
                    <p style={{ fontWeight: 600, fontSize: 14 }}>{s.label}</p>
                    <p style={{ fontSize: 12, color: '#888' }}>{s.desc}</p>
                  </div>
                  <div style={{ width: 48, height: 28, borderRadius: 28, background: '#017BFE', position: 'relative', cursor: 'pointer' }}>
                    <div style={{ position: 'absolute', right: 4, top: 4, width: 20, height: 20, borderRadius: '50%', background: 'white' }} />
                  </div>
                </div>
              ))}
              <div style={{ marginTop: 32, padding: 20, background: '#fef2f2', borderRadius: 16 }}>
                <p style={{ fontWeight: 700, color: '#ef4444', marginBottom: 8 }}>Zone de danger</p>
                <button style={{ background: 'none', border: '1px solid #ef4444', color: '#ef4444', borderRadius: 20, padding: '8px 20px', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
                  Supprimer mon compte
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
