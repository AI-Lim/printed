import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, X, ChevronDown, ChevronUp } from 'lucide-react';
import ProductCard from '../components/ui/ProductCard';
import { MOCK_PRODUCTS, CATEGORIES, PRODUCT_TYPES } from '../utils/constants';

const PRICE_RANGES = [
  { label: 'Moins de 5 000 FCFA', min: 0, max: 5000 },
  { label: '5 000 - 15 000 FCFA', min: 5000, max: 15000 },
  { label: '15 000 - 25 000 FCFA', min: 15000, max: 25000 },
  { label: 'Plus de 25 000 FCFA', min: 25000, max: Infinity },
];
const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const COLORS_LIST = ['Blanc', 'Noir', 'Bleu', 'Rouge', 'Vert', 'Jaune', 'Rose'];

function FilterSection({ title, children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div style={{ marginBottom: 20, borderBottom: '1px solid #eee', paddingBottom: 20 }}>
      <button onClick={() => setOpen(!open)} style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'none', border: 'none', cursor: 'pointer', marginBottom: open ? 12 : 0, fontWeight: 700, fontSize: 14 }}>
        {title} {open ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </button>
      {open && children}
    </div>
  );
}

export default function Catalogue() {
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('search') || '';
  const [filters, setFilters] = useState({ category: [], type: [], priceRange: null, size: [], color: [] });
  const [activeFilters, setActiveFilters] = useState([]);
  const [sortBy, setSortBy] = useState('default');
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(true);
  const PER_PAGE = 9;

  const toggleFilter = (key, value) => {
    setFilters(prev => {
      const arr = prev[key] || [];
      const next = arr.includes(value) ? arr.filter(v => v !== value) : [...arr, value];
      return { ...prev, [key]: next };
    });
    setPage(1);
  };

  const filtered = useMemo(() => {
    let p = [...MOCK_PRODUCTS];
    if (searchQuery) p = p.filter(x => x.name.toLowerCase().includes(searchQuery.toLowerCase()));
    if (filters.category.length) p = p.filter(x => filters.category.includes(x.category));
    if (filters.type.length) p = p.filter(x => filters.type.includes(x.type));
    if (filters.priceRange) p = p.filter(x => x.price >= filters.priceRange.min && x.price <= filters.priceRange.max);
    if (sortBy === 'price-asc') p.sort((a, b) => a.price - b.price);
    if (sortBy === 'price-desc') p.sort((a, b) => b.price - a.price);
    if (sortBy === 'rating') p.sort((a, b) => b.rating - a.rating);
    return p;
  }, [filters, sortBy, searchQuery]);

  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const totalPages = Math.ceil(filtered.length / PER_PAGE);

  const allActiveFilters = [
    ...filters.category.map(v => ({ key: 'category', value: v, label: v })),
    ...filters.type.map(v => ({ key: 'type', value: v, label: v })),
    ...(filters.priceRange ? [{ key: 'priceRange', value: filters.priceRange, label: filters.priceRange.label }] : []),
  ];

  return (
    <div>
      {/* Hero */}
      <div style={{ background: 'linear-gradient(135deg, #F4F4F4 0%, #CBF6FD 100%)', padding: '60px 24px', textAlign: 'center', marginBottom: 40 }}>
        <h1 style={{ fontSize: 48, fontWeight: 800, color: '#017BFE', fontFamily: 'Poppins, sans-serif', marginBottom: 8 }}>Catalogue</h1>
        {searchQuery && <p style={{ fontSize: 16, color: '#555' }}>Résultats pour : <strong>"{searchQuery}"</strong></p>}
        <p style={{ fontSize: 14, color: '#888', marginTop: 8 }}>{filtered.length} article{filtered.length > 1 ? 's' : ''} disponible{filtered.length > 1 ? 's' : ''}</p>
      </div>

      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px 60px', display: 'flex', gap: 32 }}>
        {/* Sidebar */}
        <aside style={{ width: 280, flexShrink: 0, display: showFilters ? 'block' : 'none' }}>
          <div style={{ background: 'white', borderRadius: 20, border: '1px solid rgba(132,132,132,0.3)', padding: 24, position: 'sticky', top: 90 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h3 style={{ fontWeight: 700, fontSize: 16, display: 'flex', alignItems: 'center', gap: 8 }}><Filter size={16} /> Filtres</h3>
              {allActiveFilters.length > 0 && (
                <button onClick={() => setFilters({ category: [], type: [], priceRange: null, size: [], color: [] })} style={{ fontSize: 12, color: '#017BFE', background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline' }}>Tout effacer</button>
              )}
            </div>

            <FilterSection title="Catégorie">
              {CATEGORIES.slice(0, 8).map(c => (
                <label key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, cursor: 'pointer', fontSize: 13 }}>
                  <input type="checkbox" checked={filters.category.includes(c.id)} onChange={() => toggleFilter('category', c.id)} style={{ accentColor: '#017BFE' }} />
                  {c.label}
                </label>
              ))}
            </FilterSection>

            <FilterSection title="Type de produit">
              {PRODUCT_TYPES.slice(0, 8).map(t => (
                <label key={t} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, cursor: 'pointer', fontSize: 13 }}>
                  <input type="checkbox" checked={filters.type.includes(t)} onChange={() => toggleFilter('type', t)} style={{ accentColor: '#017BFE' }} />
                  {t}
                </label>
              ))}
            </FilterSection>

            <FilterSection title="Prix">
              {PRICE_RANGES.map(range => (
                <label key={range.label} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, cursor: 'pointer', fontSize: 13 }}>
                  <input type="radio" name="price" checked={filters.priceRange?.label === range.label} onChange={() => setFilters(p => ({ ...p, priceRange: range }))} style={{ accentColor: '#017BFE' }} />
                  {range.label}
                </label>
              ))}
            </FilterSection>

            <FilterSection title="Taille">
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {SIZES.map(s => (
                  <button key={s} onClick={() => toggleFilter('size', s)} style={{ padding: '4px 12px', borderRadius: 20, border: `1px solid ${filters.size.includes(s) ? '#017BFE' : '#ddd'}`, background: filters.size.includes(s) ? '#017BFE' : 'white', color: filters.size.includes(s) ? 'white' : '#232323', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>{s}</button>
                ))}
              </div>
            </FilterSection>

            <FilterSection title="Couleur">
              {COLORS_LIST.map(c => (
                <label key={c} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, cursor: 'pointer', fontSize: 13 }}>
                  <input type="checkbox" checked={filters.color.includes(c)} onChange={() => toggleFilter('color', c)} style={{ accentColor: '#017BFE' }} />
                  {c}
                </label>
              ))}
            </FilterSection>

            <button style={{ width: '100%', background: '#017BFE', color: 'white', border: 'none', borderRadius: 20, padding: '12px', fontWeight: 700, cursor: 'pointer', fontSize: 14 }}>Valider</button>
          </div>
        </aside>

        {/* Main */}
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <button onClick={() => setShowFilters(!showFilters)} style={{ display: 'flex', alignItems: 'center', gap: 6, background: '#F4F4F4', border: 'none', borderRadius: 20, padding: '8px 16px', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
                <Filter size={14} /> {showFilters ? 'Masquer' : 'Afficher'} les filtres
              </button>
              <span style={{ fontSize: 13, color: '#888' }}>{filtered.length} articles</span>
            </div>
            <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ border: '1px solid #ddd', borderRadius: 20, padding: '8px 16px', fontSize: 13, outline: 'none', cursor: 'pointer' }}>
              <option value="default">Trier par défaut</option>
              <option value="price-asc">Prix croissant</option>
              <option value="price-desc">Prix décroissant</option>
              <option value="rating">Mieux notés</option>
            </select>
          </div>

          {/* Active Filters */}
          {allActiveFilters.length > 0 && (
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 }}>
              <span style={{ fontSize: 13, fontWeight: 700, alignSelf: 'center' }}>Filtres actifs :</span>
              {allActiveFilters.map((f, i) => (
                <span key={i} style={{ background: '#017BFE', color: 'white', padding: '4px 12px', borderRadius: 20, fontSize: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
                  {f.label}
                  <button onClick={() => f.key === 'priceRange' ? setFilters(p => ({ ...p, priceRange: null })) : toggleFilter(f.key, f.value)}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'white', display: 'flex' }}><X size={12} /></button>
                </span>
              ))}
            </div>
          )}

          {/* Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 20 }}>
            {paginated.map(p => <ProductCard key={p.id} product={p} />)}
          </div>

          {paginated.length === 0 && (
            <div style={{ textAlign: 'center', padding: '60px 0', color: '#888' }}>
              <p style={{ fontSize: 40, marginBottom: 16 }}>🔍</p>
              <p style={{ fontSize: 18, fontWeight: 600 }}>Aucun article trouvé</p>
              <p style={{ fontSize: 14 }}>Essayez d'autres filtres ou termes de recherche</p>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 8, marginTop: 40 }}>
              <button onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1}
                style={{ width: 40, height: 40, borderRadius: '50%', border: '1px solid #ddd', background: 'white', cursor: page === 1 ? 'not-allowed' : 'pointer', opacity: page === 1 ? 0.5 : 1 }}>‹</button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const p2 = i + 1;
                return (
                  <button key={p2} onClick={() => setPage(p2)} style={{ width: 40, height: 40, borderRadius: '50%', border: 'none', background: page === p2 ? '#017BFE' : 'transparent', color: page === p2 ? 'white' : '#232323', cursor: 'pointer', fontWeight: 700, fontSize: 16 }}>{p2}</button>
                );
              })}
              {totalPages > 5 && <span style={{ fontSize: 16 }}>...</span>}
              {totalPages > 5 && <button onClick={() => setPage(totalPages)} style={{ width: 40, height: 40, borderRadius: '50%', border: 'none', background: page === totalPages ? '#017BFE' : 'transparent', color: page === totalPages ? 'white' : '#232323', cursor: 'pointer', fontWeight: 700 }}>{totalPages}</button>}
              <button onClick={() => setPage(Math.min(totalPages, page + 1))} disabled={page === totalPages}
                style={{ width: 40, height: 40, borderRadius: '50%', border: '1px solid #ddd', background: 'white', cursor: page === totalPages ? 'not-allowed' : 'pointer', opacity: page === totalPages ? 0.5 : 1 }}>›</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
