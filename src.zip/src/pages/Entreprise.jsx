import { Link } from 'react-router-dom';
import { Building2, Users, Award, TrendingUp, Check } from 'lucide-react';

const OFFERS = [
  { title: 'Pack Starter', price: 'À partir de 50 000', articles: '10 articles', features: ['Personnalisation complète', 'Livraison incluse', 'Facture professionnelle', 'Support dédié'], color: '#CBF6FD' },
  { title: 'Pack Business', price: 'À partir de 150 000', articles: '30+ articles', features: ['Tout du Starter', 'Remise 15%', 'Délai prioritaire', 'Devis personnalisé', 'Logo haute résolution'], color: '#017BFE', featured: true },
  { title: 'Pack Enterprise', price: 'Sur devis', articles: '100+ articles', features: ['Tout du Business', 'Remise 25%', 'Account manager', 'Stock géré', 'Multi-site possible'], color: '#232323' },
];

export default function Entreprise() {
  return (
    <div>
      {/* Hero */}
      <div style={{ background: 'linear-gradient(135deg, #232323 0%, #017BFE 100%)', padding: '80px 24px', color: 'white', textAlign: 'center' }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>🏢</div>
        <h1 style={{ fontSize: 48, fontWeight: 800, marginBottom: 16, fontFamily: "'Mochiy Pop One', sans-serif" }}>Solutions Entreprise</h1>
        <p style={{ fontSize: 18, opacity: 0.9, maxWidth: 600, margin: '0 auto 32px', lineHeight: 1.7 }}>
          Habilleur officiel de vos équipes, vos événements, votre marque. Printed gère tout, de la personnalisation à la livraison.
        </p>
        <Link to="/contact" style={{ background: 'white', color: '#017BFE', padding: '16px 40px', borderRadius: 28, textDecoration: 'none', fontWeight: 800, fontSize: 16, display: 'inline-block' }}>
          Obtenir un devis gratuit
        </Link>
      </div>

      {/* Stats */}
      <div style={{ background: '#F4F4F4', padding: '40px 24px' }}>
        <div style={{ maxWidth: 1000, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24 }}>
          {[
            { icon: Building2, stat: '50+', label: 'Entreprises clientes' },
            { icon: Users, stat: '5 000+', label: 'Articles produits' },
            { icon: Award, stat: '4.9/5', label: 'Satisfaction client' },
            { icon: TrendingUp, stat: '48h', label: 'Délai moyen urgent' },
          ].map((s, i) => (
            <div key={i} style={{ background: 'white', borderRadius: 20, padding: 28, textAlign: 'center', boxShadow: '0 2px 12px rgba(0,0,0,0.05)' }}>
              <s.icon size={28} color="#017BFE" style={{ marginBottom: 12 }} />
              <p style={{ fontSize: 28, fontWeight: 800, color: '#017BFE', marginBottom: 4 }}>{s.stat}</p>
              <p style={{ fontSize: 13, color: '#888' }}>{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Offers */}
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '80px 24px' }}>
        <h2 style={{ textAlign: 'center', fontSize: 36, fontWeight: 800, marginBottom: 8 }}>Nos offres entreprise</h2>
        <p style={{ textAlign: 'center', color: '#888', marginBottom: 48 }}>Choisissez le pack adapté à vos besoins</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
          {OFFERS.map((offer, i) => (
            <div key={i} style={{ borderRadius: 24, overflow: 'hidden', boxShadow: offer.featured ? '0 8px 40px rgba(1,123,254,0.25)' : '0 4px 16px rgba(0,0,0,0.06)', transform: offer.featured ? 'scale(1.05)' : 'scale(1)', position: 'relative' }}>
              {offer.featured && <div style={{ background: '#E6B95E', color: 'white', textAlign: 'center', padding: '6px', fontSize: 12, fontWeight: 700 }}>⭐ LE PLUS POPULAIRE</div>}
              <div style={{ background: offer.color, padding: 32, color: offer.featured ? 'white' : (offer.color === '#232323' ? 'white' : '#232323') }}>
                <h3 style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>{offer.title}</h3>
                <p style={{ fontSize: 13, opacity: 0.8, marginBottom: 16 }}>{offer.articles}</p>
                <p style={{ fontSize: 28, fontWeight: 800 }}>{offer.price}</p>
                <p style={{ fontSize: 12, opacity: 0.7 }}>FCFA</p>
              </div>
              <div style={{ background: 'white', padding: 28 }}>
                <ul style={{ listStyle: 'none', padding: 0, marginBottom: 24 }}>
                  {offer.features.map((f, j) => (
                    <li key={j} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12, fontSize: 14 }}>
                      <div style={{ width: 20, height: 20, borderRadius: '50%', background: '#CBF6FD', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <Check size={12} color="#017BFE" />
                      </div>
                      {f}
                    </li>
                  ))}
                </ul>
                <Link to="/contact" style={{ display: 'block', textAlign: 'center', background: offer.featured ? '#017BFE' : '#232323', color: 'white', padding: '14px', borderRadius: 28, textDecoration: 'none', fontWeight: 700, fontSize: 14 }}>
                  Demander ce pack
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Use cases */}
      <div style={{ background: '#CBF6FD', padding: '60px 24px' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto', textAlign: 'center' }}>
          <h2 style={{ fontSize: 32, fontWeight: 800, marginBottom: 40 }}>Ils nous font confiance</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 20 }}>
            {[
              { emoji: '🎓', title: 'Universités & Écoles', desc: 'Uniformes, événements, clubs étudiants' },
              { emoji: '🏪', title: 'PME & Startups', desc: 'Goodies, uniformes, articles pub' },
              { emoji: '🎉', title: 'Événements', desc: 'Mariages, anniversaires, galas' },
              { emoji: '⚽', title: 'Clubs Sportifs', desc: 'Maillots, tenues d\'entraînement' },
              { emoji: '🎤', title: 'Artistes', desc: 'Merch officiel, tournées, concerts' },
            ].map((u, i) => (
              <div key={i} style={{ background: 'white', borderRadius: 16, padding: 24, textAlign: 'center' }}>
                <div style={{ fontSize: 48, marginBottom: 12 }}>{u.emoji}</div>
                <p style={{ fontWeight: 700, fontSize: 15, marginBottom: 6 }}>{u.title}</p>
                <p style={{ fontSize: 13, color: '#666' }}>{u.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
