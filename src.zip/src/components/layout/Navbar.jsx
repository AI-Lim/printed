import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ShoppingCart, User, Search, Menu, X, LogOut, Settings, Package } from 'lucide-react';
import { useCart, useAuth } from '../../context/AppContext';
import { FIGMA_ASSETS, NAV_LINKS } from '../../utils/constants';

export default function Navbar() {
  const location  = useLocation();
  const navigate  = useNavigate();
  const { count } = useCart();
  const { user, logout, isAdmin } = useAuth();

  const [mobileOpen,  setMobileOpen]  = useState(false);
  const [userMenuOpen,setUserMenuOpen] = useState(false);
  const [query,       setQuery]        = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/catalogue?search=${encodeURIComponent(query.trim())}`);
      setMobileOpen(false);
    }
  };

  const closeAll = () => { setMobileOpen(false); setUserMenuOpen(false); };

  const S = {
    header: {
      background: '#F4F4F4',
      boxShadow: '0 4px 4px rgba(0,0,0,0.1)',
      position: 'sticky', top: 0, zIndex: 50,
    },
    inner: {
      maxWidth: 1280, margin: '0 auto',
      padding: '0 24px', height: 70,
      display: 'flex', alignItems: 'center', gap: 24,
    },
    navLink: (active) => ({
      fontSize: 12, fontWeight: 600, textDecoration: 'none',
      color: active ? '#017BFE' : '#232323',
      position: 'relative', paddingBottom: 4,
    }),
    activeLine: {
      position: 'absolute', bottom: -2, left: 0,
      width: '100%', height: 3,
      background: '#017BFE', borderRadius: 2,
    },
    iconBtn: {
      background: 'white', border: 'none', borderRadius: '50%',
      width: 32, height: 32,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer', position: 'relative',
    },
  };

  return (
    <header style={S.header}>
      <div style={S.inner}>
        {/* Logo */}
        <Link to="/" onClick={closeAll}>
          <img src={FIGMA_ASSETS.logo} alt="Printed" style={{ height: 40, objectFit: 'contain' }} />
        </Link>

        {/* Desktop nav */}
        <nav style={{ display: 'flex', gap: 24, flex: 1 }} className="hide-mobile">
          {NAV_LINKS.map(link => {
            const active = location.pathname === link.path;
            return (
              <Link key={link.path} to={link.path} style={S.navLink(active)}>
                {link.label}
                {active && <span style={S.activeLine} />}
              </Link>
            );
          })}
        </nav>

        {/* Search bar desktop */}
        <form onSubmit={handleSearch}
          style={{ position: 'relative', minWidth: 200 }}
          className="hide-mobile">
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Rechercher..."
            style={{
              background: 'white', border: 'none', borderRadius: 28,
              padding: '6px 36px 6px 16px', fontSize: 12, outline: 'none', width: '100%',
            }}
          />
          <button type="submit" style={{
            position: 'absolute', right: 12, top: '50%',
            transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer',
          }}>
            <Search size={14} color="#999" />
          </button>
        </form>

        {/* Actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {/* User dropdown */}
          <div style={{ position: 'relative' }}>
            <button style={S.iconBtn} onClick={() => setUserMenuOpen(o => !o)}>
              {user
                ? <span style={{ fontSize: 13, fontWeight: 700, color: '#017BFE' }}>{user.name[0]}</span>
                : <User size={18} color="#232323" />}
            </button>
            {userMenuOpen && (
              <div style={{
                position: 'absolute', right: 0, top: 'calc(100% + 8px)',
                background: 'white', borderRadius: 16,
                boxShadow: '0 8px 32px rgba(0,0,0,0.15)',
                padding: '8px 0', minWidth: 190, zIndex: 100,
              }}>
                {user ? (
                  <>
                    <div style={{ padding: '8px 16px 12px', borderBottom: '1px solid #f0f0f0' }}>
                      <p style={{ fontWeight: 700, fontSize: 13 }}>{user.name}</p>
                      <p style={{ fontSize: 11, color: '#888', marginTop: 2 }}>{user.email}</p>
                    </div>
                    {[
                      { to: '/profil',   icon: User,     label: 'Mon profil' },
                      { to: '/commandes',icon: Package,  label: 'Mes commandes' },
                    ].map(item => (
                      <Link key={item.to} to={item.to} onClick={closeAll}
                        style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 16px', fontSize: 13, color: '#232323', textDecoration: 'none' }}>
                        <item.icon size={13} /> {item.label}
                      </Link>
                    ))}
                    {isAdmin && (
                      <Link to="/admin" onClick={closeAll}
                        style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 16px', fontSize: 13, color: '#017BFE', textDecoration: 'none' }}>
                        <Settings size={13} /> Panel Admin
                      </Link>
                    )}
                    <div style={{ borderTop: '1px solid #f0f0f0', marginTop: 4 }}>
                      <button onClick={() => { logout(); closeAll(); navigate('/'); }}
                        style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 16px', fontSize: 13, color: '#ef4444', background: 'none', border: 'none', cursor: 'pointer', width: '100%' }}>
                        <LogOut size={13} /> Se déconnecter
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <Link to="/connexion"  onClick={closeAll} style={{ display: 'block', padding: '10px 16px', fontSize: 13, color: '#232323', textDecoration: 'none' }}>Se connecter</Link>
                    <Link to="/inscription" onClick={closeAll} style={{ display: 'block', padding: '10px 16px', fontSize: 13, color: '#017BFE', fontWeight: 700, textDecoration: 'none' }}>S'inscrire</Link>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Cart */}
          <Link to="/panier" onClick={closeAll} style={{ ...S.iconBtn, textDecoration: 'none' }}>
            <ShoppingCart size={18} color="#232323" />
            {count > 0 && (
              <span style={{
                position: 'absolute', top: -4, right: -4,
                background: '#017BFE', color: 'white',
                borderRadius: '50%', width: 17, height: 17,
                fontSize: 10, fontWeight: 700,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                border: '2px solid #F4F4F4',
              }}>
                {count > 9 ? '9+' : count}
              </span>
            )}
          </Link>

          {/* Mobile hamburger */}
          <button
            className="show-mobile"
            onClick={() => setMobileOpen(o => !o)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div style={{ background: 'white', borderTop: '1px solid #eee', padding: '16px 24px', display: 'flex', flexDirection: 'column', gap: 4 }}>
          <form onSubmit={handleSearch} style={{ position: 'relative', marginBottom: 12 }}>
            <input value={query} onChange={e => setQuery(e.target.value)}
              placeholder="Rechercher..."
              style={{ width: '100%', border: '1px solid #eee', borderRadius: 28, padding: '9px 36px 9px 14px', fontSize: 13, outline: 'none', fontFamily: 'Poppins, sans-serif' }} />
            <button type="submit" style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none' }}>
              <Search size={14} color="#999" />
            </button>
          </form>
          {NAV_LINKS.map(link => (
            <Link key={link.path} to={link.path} onClick={closeAll}
              style={{ fontSize: 14, fontWeight: 600, color: location.pathname === link.path ? '#017BFE' : '#232323', textDecoration: 'none', padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
              {link.label}
            </Link>
          ))}
          {!user && (
            <div style={{ display: 'flex', gap: 12, paddingTop: 12 }}>
              <Link to="/connexion" onClick={closeAll}
                style={{ flex: 1, textAlign: 'center', padding: '10px', borderRadius: 28, border: '2px solid #017BFE', color: '#017BFE', textDecoration: 'none', fontWeight: 700, fontSize: 13 }}>
                Connexion
              </Link>
              <Link to="/inscription" onClick={closeAll}
                style={{ flex: 1, textAlign: 'center', padding: '10px', borderRadius: 28, background: '#017BFE', color: 'white', textDecoration: 'none', fontWeight: 700, fontSize: 13 }}>
                S'inscrire
              </Link>
            </div>
          )}
        </div>
      )}
    </header>
  );
}
