import { Link } from 'react-router-dom';
import { FIGMA_ASSETS } from '../../utils/constants';

const FOOTER_COLS = [
  {
    title: 'À propos',
    links: ['Blog', 'Comment ça marche', 'Témoignages', 'Notre mission'],
    paths: ['/blog', '/blog', '/blog', '/blog'],
  },
  {
    title: 'Boutique',
    links: ['Nouveautés', 'Best-sellers', 'Catégories', 'Promotions'],
    paths: ['/catalogue', '/catalogue', '/catalogue', '/catalogue'],
  },
  {
    title: 'Support & Aide',
    links: ['FAQ', 'Suivi de commande', 'Politique de retour', 'Contactez-nous'],
    paths: ['/contact', '/commandes', '/contact', '/contact'],
  },
  {
    title: 'Mentions légales',
    links: ['Mentions légales', 'CGV', 'Politique de confidentialité', 'Politique des cookies'],
    paths: ['#', '#', '#', '#'],
  },
];

export default function Footer() {
  return (
    <footer style={{ background: 'white', borderTop: '1px solid #eee', marginTop: 'auto' }}>
      <div style={{
        maxWidth: 1280, margin: '0 auto',
        padding: '48px 24px 32px',
        display: 'grid',
        gridTemplateColumns: '220px repeat(4, 1fr)',
        gap: 32,
      }}>
        {/* Brand */}
        <div>
          <img src={FIGMA_ASSETS.logo} alt="Printed" style={{ height: 48, marginBottom: 14 }} />
          <p style={{ fontSize: 12, color: '#666', lineHeight: 1.7, marginBottom: 16 }}>
            Rejoignez la communauté Printed et partagez vos créations !
          </p>
          <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
            {[
              { img: FIGMA_ASSETS.facebook,  alt: 'Facebook',  href: '#' },
              { img: FIGMA_ASSETS.instagram, alt: 'Instagram', href: '#' },
              { img: FIGMA_ASSETS.tiktok,    alt: 'TikTok',    href: '#' },
            ].map(s => (
              <a key={s.alt} href={s.href}>
                <img src={s.img} alt={s.alt} style={{ width: 24, height: 24, objectFit: 'contain' }} />
              </a>
            ))}
          </div>
          <p style={{ fontSize: 13, fontWeight: 700, color: '#017BFE' }}>Print your style</p>
        </div>

        {/* Columns */}
        {FOOTER_COLS.map(col => (
          <div key={col.title}>
            <h4 style={{ fontSize: 14, fontWeight: 700, marginBottom: 14, color: '#232323' }}>{col.title}</h4>
            {col.links.map((label, i) => (
              <Link key={label} to={col.paths[i]}
                style={{ display: 'block', fontSize: 13, color: '#666', textDecoration: 'none', marginBottom: 8, lineHeight: 1.6, transition: 'color 0.2s' }}
                onMouseEnter={e => e.target.style.color = '#017BFE'}
                onMouseLeave={e => e.target.style.color = '#666'}>
                {label}
              </Link>
            ))}
          </div>
        ))}
      </div>

      <div style={{ borderTop: '1px solid #eee', textAlign: 'center', padding: '16px 24px', fontSize: 11, color: '#aaa' }}>
        © 2025 Printed. Tous droits réservés. — Abomey-Calavi, Bénin
      </div>
    </footer>
  );
}
